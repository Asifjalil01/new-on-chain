import React, { useEffect } from 'react';
import {
  LayoutDashboard,
  Radio,
  Activity,
  Layers,
  Shield,
  Wallet,
  History,
  Settings,
  FileText,
  ChevronLeft,
  ChevronRight,
  Lock,
} from 'lucide-react';
import { useBot } from '../context/BotContext';

export const Sidebar: React.FC = () => {
  const {
    currentTab,
    navigateToTab,
    positions,
    universeTotal,
    isBotStopped,
    config,
    sidebarState,
    setSidebarState,
    toggleSidebar,
  } = useBot();

  // Keyboard shortcut Ctrl+B / Cmd+B to toggle sidebar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'b' || e.key === 'B')) {
        e.preventDefault();
        toggleSidebar();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [toggleSidebar]);

  const navItems = [
    { id: 'dashboard', label: 'DASHBOARD', icon: LayoutDashboard, badge: positions.length ? `${positions.length}` : undefined },
    { id: 'scanner', label: 'SCANNER', icon: Radio, badge: universeTotal ? `${universeTotal}` : undefined },
    { id: 'token_detail', label: 'TOKEN DETAIL', icon: Activity },
    { id: 'coverage', label: 'COVERAGE', icon: Layers },
    { id: 'rug_defense', label: 'RUG DEFENSE', icon: Shield },
    { id: 'wallets', label: 'WALLETS', icon: Wallet },
    { id: 'history', label: 'HISTORY', icon: History },
    { id: 'settings', label: 'SETTINGS', icon: Settings },
    { id: 'docs', label: 'DOCS', icon: FileText },
  ];

  const isLive = config.EXECUTION_MODE === 'live';

  return (
    <>
      {/* If hidden, show a neat zero-overlap mini rail tab docked at the left border */}
      {sidebarState === 'hidden' && (
        <button
          onClick={() => setSidebarState('expanded')}
          title="Expand Sidebar (Ctrl+B)"
          className="h-full w-4 bg-[var(--panel)] border-r border-[var(--border)] hover:bg-[var(--card)] hover:w-5 flex items-center justify-center text-[var(--muted)] hover:text-[var(--teal)] transition-all cursor-pointer z-20 shrink-0"
        >
          <ChevronRight size={13} />
        </button>
      )}

      {/* Sidebar Container */}
      <aside
        className={`h-full bg-[var(--panel)] border-r border-[var(--border)] flex flex-col shrink-0 select-none transition-all duration-200 ease-in-out z-20 ${
          sidebarState === 'hidden' ? 'w-0 overflow-hidden border-none' : ''
        } ${sidebarState === 'collapsed' ? 'w-[58px]' : ''} ${
          sidebarState === 'expanded' ? 'w-[205px]' : ''
        }`}
      >
        {/* Sidebar Header & Toggle */}
        <div className="h-[42px] px-3 border-b border-[var(--border)] flex items-center justify-between shrink-0">
          {sidebarState === 'expanded' && (
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="w-2 h-2 rounded-full bg-[var(--teal)] shrink-0"></span>
              <span className="text-[11px] font-bold text-[var(--text)] tracking-wider truncate">
                NAVIGATION
              </span>
            </div>
          )}

          {sidebarState === 'collapsed' && (
            <span className="mx-auto text-[11px] text-[var(--teal)] font-bold">◈</span>
          )}

          <div className="flex items-center gap-1 ml-auto">
            {sidebarState === 'expanded' && (
              <button
                onClick={() => setSidebarState('collapsed')}
                title="Collapse to icons (Ctrl+B)"
                className="p-1 rounded text-[var(--muted)] hover:text-[var(--teal)] hover:bg-[var(--card)] cursor-pointer transition-colors"
              >
                <ChevronLeft size={14} />
              </button>
            )}
            {sidebarState === 'collapsed' && (
              <button
                onClick={() => setSidebarState('expanded')}
                title="Expand Sidebar (Ctrl+B)"
                className="p-1 rounded text-[var(--muted)] hover:text-[var(--teal)] hover:bg-[var(--card)] cursor-pointer transition-colors mx-auto"
              >
                <ChevronRight size={14} />
              </button>
            )}
          </div>
        </div>

        {/* Live Mode Badge in Sidebar */}
        {sidebarState === 'expanded' && isLive && (
          <div className="m-2 p-1.5 rounded border border-[var(--red)]/40 bg-[var(--red)]/10 text-[var(--red)] text-[10px] font-bold flex items-center gap-1.5 animate-pulse">
            <Lock size={12} className="shrink-0" />
            <span className="truncate">LIVE MAINNET ENGAGED</span>
          </div>
        )}

        {/* Stopped Warning in Sidebar */}
        {sidebarState === 'expanded' && isBotStopped && (
          <div className="mx-2 my-1.5 p-1.5 rounded border border-[var(--yellow)]/40 bg-[var(--yellow)]/10 text-[var(--yellow)] text-[10px] font-bold text-center">
            BOT STOPPED
          </div>
        )}

        {/* Navigation Items List */}
        <nav className="flex-1 py-2 overflow-y-auto space-y-0.5 px-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => navigateToTab(item.id)}
                title={sidebarState === 'collapsed' ? item.label : undefined}
                className={`w-full flex items-center rounded transition-all cursor-pointer group text-xs ${
                  sidebarState === 'collapsed'
                    ? 'justify-center py-2.5 px-0'
                    : 'justify-between py-2 px-2.5'
                } ${
                  isActive
                    ? 'bg-[var(--teal)]/15 text-[var(--teal)] font-bold border border-[var(--teal)]/40 shadow-xs'
                    : 'text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--card)] border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    size={15}
                    className={`shrink-0 transition-transform ${
                      isActive ? 'text-[var(--teal)] scale-110' : 'text-[var(--dim)] group-hover:text-[var(--text)]'
                    }`}
                  />
                  {sidebarState === 'expanded' && (
                    <span className="truncate tracking-wide">{item.label}</span>
                  )}
                </div>

                {sidebarState === 'expanded' && item.badge && (
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold ${
                      isActive
                        ? 'bg-[var(--teal)] text-[var(--bg)]'
                        : 'bg-[var(--panel)] text-[var(--muted)] border border-[var(--border)]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        {sidebarState === 'expanded' && (
          <div className="p-2 border-t border-[var(--border)] text-[10px] text-[var(--dim)] font-mono flex items-center justify-between">
            <span>[CTRL+B]</span>
            <span className="text-[var(--teal)] font-bold">v2.3.1</span>
          </div>
        )}
      </aside>
    </>
  );
};
