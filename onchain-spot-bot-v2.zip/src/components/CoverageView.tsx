import React from 'react';
import { Layers, Activity, AlertCircle, CheckCircle, TrendingUp, Sparkles, Filter, ShieldCheck } from 'lucide-react';

interface ChainCoverage {
  chain: string;
  total_tracked: number;
  tier0_scanned: number;
  coverage_pct: number;
  requests_per_min: number;
  latency_ms: number;
  status: string;
}

interface DiscoveryStats {
  candidates_fetched_this_cycle: number;
  passed_prefilter_this_cycle: number;
  passed_deep_checks_this_cycle: number;
  rejected_this_cycle: number;
  rejected_reasons_breakdown: Record<string, number>;
  new_tokens_discovered_this_cycle: number;
  total_seen_tokens: number;
  new_per_hour: number;
  repeated_vs_new_ratio: string;
  last_scan_duration_ms: number;
  source_breakdown: Record<string, number>;
}

interface CoverageData {
  per_chain: ChainCoverage[];
  total_universe_size: number;
  queue_depth: number;
  discovery_lag_seconds: number;
  discovery_stats?: DiscoveryStats;
  provider_health: {
    dexscreener: { status: string; latency_ms: number; req_used_pct: number };
    geckoterminal: { status: string; latency_ms: number; req_used_pct: number };
    goplus: { status: string; latency_ms: number; req_used_pct: number };
    solana_rpc: { status: string; latency_ms: number; req_used_pct: number };
  };
}

interface CoverageViewProps {
  coverage: CoverageData | null;
}

export const CoverageView: React.FC<CoverageViewProps> = ({ coverage }) => {
  if (!coverage) {
    return (
      <div className="flex-1 flex items-center justify-center text-xs text-[var(--muted)]">
        Loading measured coverage data...
      </div>
    );
  }

  const ds = coverage.discovery_stats || {
    candidates_fetched_this_cycle: 0,
    passed_prefilter_this_cycle: 0,
    passed_deep_checks_this_cycle: 0,
    rejected_this_cycle: 0,
    rejected_reasons_breakdown: {},
    new_tokens_discovered_this_cycle: 0,
    total_seen_tokens: 0,
    new_per_hour: 0,
    repeated_vs_new_ratio: '0%',
    last_scan_duration_ms: 0,
    source_breakdown: {},
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[var(--bg)] p-4 space-y-4">
      {/* 1. DISCOVERY COVERAGE BANNER: PROOF OF FRESH TOKENS */}
      <div className="bg-[var(--card)] border border-[var(--teal)]/40 rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-[var(--teal)]" />
            <h2 className="text-xs font-bold text-[var(--text)] tracking-wider">
              DISCOVERY INTAKE & COVERAGE PIPELINE
            </h2>
          </div>
          <span className="text-[10px] text-[var(--green)] font-mono font-bold flex items-center gap-1">
            <CheckCircle size={10} /> CONTINUOUS ROTATION ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)]">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">NEW DISCOVERIES / HR</div>
            <div className="text-lg font-bold text-[var(--green)] font-mono">+{ds.new_per_hour} tokens</div>
            <div className="text-[9px] text-[var(--dim)] mt-0.5">Rolling 60m velocity</div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)]">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">REPEATED VS NEW RATIO</div>
            <div className="text-lg font-bold text-[var(--teal)] font-mono">{ds.repeated_vs_new_ratio}</div>
            <div className="text-[9px] text-[var(--dim)] mt-0.5">Market churn rate</div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)]">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">SEEN TOKENS REGISTRY</div>
            <div className="text-lg font-bold text-[var(--text)] font-mono">{ds.total_seen_tokens}</div>
            <div className="text-[9px] text-[var(--dim)] mt-0.5">Deduplicated addresses</div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)]">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">DISCOVERY LAG</div>
            <div className="text-lg font-bold text-[var(--text)] font-mono">{coverage.discovery_lag_seconds}s</div>
            <div className="text-[9px] text-[var(--dim)] mt-0.5">Intake to evaluation</div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)]">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">LAST CYCLE DURATION</div>
            <div className="text-lg font-bold text-[var(--yellow)] font-mono">{(ds.last_scan_duration_ms / 1000).toFixed(1)}s</div>
            <div className="text-[9px] text-[var(--dim)] mt-0.5">Multi-source fetch time</div>
          </div>
        </div>

        {/* Funnel Progress Visualizer */}
        <div className="pt-2">
          <div className="text-[10px] uppercase font-bold text-[var(--dim)] mb-1.5 flex items-center justify-between">
            <span>PIPELINE FILTRATION FUNNEL (CURRENT CYCLE)</span>
            <span>
              {ds.candidates_fetched_this_cycle} Raw → {ds.passed_prefilter_this_cycle} Pre-Filter Passed → {ds.passed_deep_checks_this_cycle} Audited
            </span>
          </div>
          <div className="w-full bg-[var(--panel)] h-2 rounded-full overflow-hidden flex">
            <div
              className="bg-[var(--green)] h-full transition-all"
              style={{
                width: `${Math.min(100, Math.max(5, (ds.passed_deep_checks_this_cycle / Math.max(1, ds.candidates_fetched_this_cycle)) * 100))}%`,
              }}
              title="Passed Deep Audit"
            ></div>
            <div
              className="bg-[var(--teal)] h-full transition-all"
              style={{
                width: `${Math.min(100, Math.max(5, ((ds.passed_prefilter_this_cycle - ds.passed_deep_checks_this_cycle) / Math.max(1, ds.candidates_fetched_this_cycle)) * 100))}%`,
              }}
              title="Passed Pre-Filter"
            ></div>
            <div
              className="bg-[var(--red)]/50 h-full transition-all flex-1"
              title="Rejected by Filters"
            ></div>
          </div>
        </div>
      </div>

      {/* 2. REJECTION REASON BREAKDOWN */}
      {Object.keys(ds.rejected_reasons_breakdown).length > 0 && (
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4">
          <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-3 tracking-wider flex items-center gap-1.5">
            <Filter size={13} className="text-[var(--red)]" />
            <span>FILTER REJECTION CAUSES (THIS CYCLE)</span>
          </h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            {Object.entries(ds.rejected_reasons_breakdown).map(([reason, count]) => (
              <div key={reason} className="p-2 rounded bg-[var(--panel)] border border-[var(--border)] flex items-center justify-between">
                <span className="text-[11px] font-mono text-[var(--muted)]">{reason}</span>
                <span className="font-bold font-mono text-[var(--red)]">{count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. PROVIDER HEALTH & RATE LIMIT METERS */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4">
        <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-3 tracking-wider flex items-center gap-2">
          <Activity size={14} className="text-[var(--teal)]" />
          <span>EXTERNAL API RATE LIMITS & PROVIDER HEALTH</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          {Object.entries(coverage.provider_health).map(([pName, pVal]) => (
            <div key={pName} className="p-2.5 rounded bg-[var(--panel)] border border-[var(--border)] flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[var(--text)] uppercase">{pName}</span>
                <span className="text-[10px] text-[var(--green)] flex items-center gap-1 font-bold">
                  <CheckCircle size={10} /> {pVal.status}
                </span>
              </div>
              <div className="text-[11px] text-[var(--muted)] flex justify-between">
                <span>Latency: {pVal.latency_ms}ms</span>
                <span>Limit used: {pVal.req_used_pct}%</span>
              </div>
              <div className="w-full bg-[var(--bg)] h-1.5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[var(--teal)]"
                  style={{ width: `${pVal.req_used_pct}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. PER-CHAIN COVERAGE TABLE */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 flex flex-col flex-1">
        <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-3 tracking-wider flex items-center gap-2">
          <Layers size={14} className="text-[var(--teal)]" />
          <span>PER-CHAIN MEASURED COVERAGE & LATENCY</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-left text-xs font-mono">
            <thead>
              <tr className="border-b border-[var(--border)] text-[10px] text-[var(--dim)] uppercase">
                <th className="py-2 px-3">BLOCKCHAIN</th>
                <th className="py-2 px-3 text-right">TOKENS DISCOVERED</th>
                <th className="py-2 px-3 text-right">AUDITED</th>
                <th className="py-2 px-3 text-right">COVERAGE</th>
                <th className="py-2 px-3 text-right">REQUESTS/MIN</th>
                <th className="py-2 px-3 text-right">LATENCY</th>
                <th className="py-2 px-3 text-center">CIRCUIT STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {coverage.per_chain.map((c) => (
                <tr key={c.chain} className="hover:bg-[var(--card-hover)] transition-colors">
                  <td className="py-2.5 px-3 font-bold text-[var(--text)] uppercase">{c.chain}</td>
                  <td className="py-2.5 px-3 text-right text-[var(--teal)] font-bold">{c.total_tracked}</td>
                  <td className="py-2.5 px-3 text-right text-[var(--muted)]">{c.tier0_scanned}</td>
                  <td className="py-2.5 px-3 text-right text-[var(--green)] font-bold">{c.coverage_pct.toFixed(1)}%</td>
                  <td className="py-2.5 px-3 text-right text-[var(--muted)]">{c.requests_per_min} req/m</td>
                  <td className="py-2.5 px-3 text-right text-[var(--dim)]">{c.latency_ms} ms</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold border border-[var(--green)]/30 bg-[var(--green)]/10 text-[var(--green)]">
                      {c.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
