import React, { useState, useCallback } from 'react';
import { Copy, Check, TrendingUp, TrendingDown, Clock, ShieldCheck, DollarSign, ExternalLink } from 'lucide-react';
import { formatPrice, formatUsd, formatTimeAgo } from '../utils/formatters';

interface Position {
  position_id: string;
  chain: string;
  token_address: string;
  pair_address: string;
  symbol: string;
  name: string;
  dex: string;
  quote_token?: string;
  quote_address?: string;
  entry_price_usd: number;
  current_price_usd: number;
  peak_price_usd: number;
  quantity: number;
  cost_basis_usd: number;
  current_value_usd: number;
  entry_timestamp: number;
  peak_profit_percent: number;
  current_profit_percent: number;
  trailing_tier_label: string;
  trailing_floor_price_usd: number;
  state: string;
  gas_spent_usd: number;
  fees_spent_usd: number;
  priority_fee_usd?: number;
  total_fees_usd?: number;
  total_cost_usd?: number;
  wallet_id?: string;
  wallet_name?: string;
  wallet_fee_pct?: number;
  allocated_amount?: number;
  allocated_currency?: string;
  price_source?: string;
  price_updated_at?: number;
  price_native?: number;
  liquidity_usd?: number;
  volume_24h_usd?: number;
  price_impact_pct?: number;
  expected_execution_price_usd?: number;
  reference_price_usd?: number;
  break_even_price_usd?: number;
  estimated_exit_fees_usd?: number;
  net_profit_usd?: number;
  net_profit_percent?: number;
  net_peak_profit_percent?: number;
  is_price_stale?: boolean;
  price_status?: 'FRESH' | 'STALE';
  data_age_seconds?: number;
}

interface QuickStats {
  total_balance: number;
  cash_balance: number;
  invested_capital: number;
  unrealized_pnl: number;
  unrealized_pnl_pct: number;
  realized_pnl: number;
  open_positions_count: number;
  total_trades: number;
  win_rate_pct: number;
  wins_count: number;
  losses_count: number;
}

interface AppLog {
  id: string;
  timestamp: number;
  type: string;
  severity: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  message: string;
}

interface DashboardViewProps {
  positions: Position[];
  stats: QuickStats;
  logs: AppLog[];
  onSellPosition: (positionId: string) => void;
  onSellAll: () => void;
  onInspectToken: (chain: string, address: string) => void;
}

// ---------------- MEMOIZED POSITION CARD ----------------
// Only re-renders when this specific position's price, state, or selection changes
const PositionCard = React.memo<{
  pos: Position;
  isSelected: boolean;
  isCopied: boolean;
  onSelect: (addr: string) => void;
  onCopy: (text: string, id: string) => void;
  onInspect: (chain: string, address: string) => void;
  onSell: (posId: string) => void;
}>(({ pos, isSelected, isCopied, onSelect, onCopy, onInspect, onSell }) => {
  const isProfit = pos.current_profit_percent >= 0;
  const progressWidth = Math.min(100, Math.max(5, (pos.current_profit_percent / Math.max(20, pos.peak_profit_percent)) * 100));

  return (
    <div
      onClick={() => onSelect(pos.token_address)}
      className={`bg-[var(--card)] border rounded p-3 flex flex-col gap-2.5 transition-all cursor-pointer ${
        isSelected
          ? 'border-[var(--teal)] ring-1 ring-[var(--teal)]/40'
          : 'border-[var(--border)] hover:border-[var(--border-bright)] hover:bg-[var(--card-hover)]'
      }`}
    >
      {/* Card Header: Symbol, DEX, P&L %, Held Time */}
      <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-base font-bold text-[var(--text)]">{pos.symbol}</span>
          <span className="text-[10px] text-[var(--teal)] font-mono font-bold px-1.5 py-0.2 rounded border border-[var(--teal)]/40 bg-[var(--panel)]">
            {pos.symbol}/{pos.quote_token || (pos.chain.toLowerCase() === 'solana' ? 'SOL' : 'ETH')}
          </span>
          <span className="text-[10px] text-[var(--muted)] px-1.5 py-0.2 rounded border border-[var(--border)] uppercase">
            {pos.chain}:{pos.dex}
          </span>
          {pos.wallet_name && (
            <span className="text-[10px] text-[var(--yellow)] font-mono font-semibold px-1.5 py-0.2 rounded border border-[var(--yellow)]/30 bg-[var(--yellow)]/10">
              {pos.wallet_name.split(' ')[0]} ({pos.wallet_fee_pct ?? 0.85}%)
            </span>
          )}
          <span
            className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
              pos.state === 'RECOVERY_WATCH'
                ? 'border-[var(--yellow)] text-[var(--yellow)] bg-[var(--yellow)]/10'
                : 'border-[var(--teal)] text-[var(--teal)] bg-[var(--teal)]/10'
            }`}
          >
            {pos.state}
          </span>
          {pos.is_price_stale ? (
            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded border border-[var(--red)]/50 bg-[var(--red)]/15 text-[var(--red)] animate-pulse">
              STALE ({pos.data_age_seconds || 3}s)
            </span>
          ) : (
            <span className="text-[9px] font-semibold px-1.5 py-0.2 rounded border border-[var(--green)]/40 bg-[var(--green)]/10 text-[var(--green)]">
              LIVE (&le;1s)
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="text-right">
            <div className={`text-base font-bold flex items-center justify-end gap-0.5 ${isProfit ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
              {isProfit ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
              {isProfit ? '+' : ''}{pos.current_profit_percent.toFixed(2)}%
            </div>
            <div className="text-[10px] font-mono text-[var(--muted)]">
              Net:{' '}
              <span className={(pos.net_profit_percent ?? pos.current_profit_percent) >= 0 ? 'text-[var(--green)] font-semibold' : 'text-[var(--red)] font-semibold'}>
                {pos.net_profit_percent !== undefined
                  ? `${pos.net_profit_percent >= 0 ? '+' : ''}${pos.net_profit_percent.toFixed(2)}%`
                  : `${isProfit ? '+' : ''}${pos.current_profit_percent.toFixed(2)}%`}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Price Source & Verified Pool Sub-header */}
      <div className="flex items-center justify-between text-[10px] text-[var(--dim)] px-1">
        <span className="truncate max-w-[180px]">
          Source: <span className="text-[var(--teal)] font-mono">{pos.price_source || `DexScreener (${pos.dex?.toUpperCase()} Pool)`}</span>
        </span>
        {pos.pair_address && (
          <a
            href={`https://dexscreener.com/${pos.chain}/${pos.pair_address}`}
            target="_blank"
            rel="noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-0.5 text-[var(--blue)] hover:underline font-mono text-[10px]"
          >
            <span>Pair: {pos.pair_address.slice(0, 6)}...{pos.pair_address.slice(-4)}</span>
            <ExternalLink size={9} />
          </a>
        )}
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-3 gap-2 text-xs">
        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">ENTRY PRICE</div>
          <div className="font-mono text-[var(--text)] font-semibold">{formatPrice(pos.entry_price_usd)}</div>
        </div>
        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">CURRENT PRICE</div>
          <div className="font-mono text-[var(--text)] font-semibold">{formatPrice(pos.current_price_usd)}</div>
        </div>
        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">BREAK-EVEN</div>
          <div className="font-mono text-[var(--yellow)] font-semibold">{formatPrice(pos.break_even_price_usd || pos.entry_price_usd)}</div>
        </div>

        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">PEAK PRICE</div>
          <div className="font-mono text-[var(--teal)] font-semibold">{formatPrice(pos.peak_price_usd)} (+{pos.peak_profit_percent.toFixed(1)}%)</div>
        </div>
        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">COST BASIS</div>
          <div className="font-mono text-[var(--muted)]">{formatUsd(pos.cost_basis_usd)}</div>
        </div>
        <div>
          <div className="text-[var(--dim)] text-[10px] uppercase">CURRENT VALUE</div>
          <div className="font-mono text-[var(--text)] font-bold">{formatUsd(pos.current_value_usd)}</div>
        </div>
      </div>

      {/* Transparent Itemized Fees Row */}
      <div className="bg-[var(--panel)]/90 px-2.5 py-1.5 rounded border border-[var(--border)] text-[10px] flex items-center justify-between text-[var(--muted)]">
        <div className="flex items-center gap-1.5">
          <span className="text-[var(--dim)] uppercase font-semibold">ALL FEES:</span>
          <span className="font-mono text-[var(--yellow)] font-bold">
            {formatUsd(pos.total_fees_usd || (pos.fees_spent_usd + pos.gas_spent_usd))}
          </span>
        </div>
        <div className="text-[10px] text-[var(--dim)] flex items-center gap-2 font-mono">
          <span>DEX: {formatUsd(pos.fees_spent_usd)}</span>
          <span>Gas: {formatUsd(pos.gas_spent_usd)}</span>
          {pos.priority_fee_usd ? <span>Tip: {formatUsd(pos.priority_fee_usd)}</span> : null}
        </div>
      </div>

      {/* Trailing Tier & Floor Progress Bar */}
      <div className="bg-[var(--panel)]/70 p-2 rounded border border-[var(--border)] flex flex-col gap-1 text-[11px]">
        <div className="flex items-center justify-between text-[var(--muted)]">
          <span className="font-bold text-[var(--yellow)]">{pos.trailing_tier_label}</span>
          <span>Floor: <span className="font-mono text-[var(--text)]">{formatPrice(pos.trailing_floor_price_usd)}</span></span>
        </div>
        <div className="w-full bg-[var(--bg)] h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full ${isProfit ? 'bg-[var(--teal)]' : 'bg-[var(--red)]'} transition-all duration-300`}
            style={{ width: `${progressWidth}%` }}
          ></div>
        </div>
      </div>

      {/* Held Time & Address Field */}
      <div className="flex items-center justify-between text-[11px] text-[var(--dim)]">
        <span className="flex items-center gap-1">
          <Clock size={11} /> Held: {formatTimeAgo(pos.entry_timestamp)}
        </span>
        <span className="font-mono truncate max-w-[140px] text-[var(--muted)]">
          {pos.token_address.slice(0, 6)}...{pos.token_address.slice(-4)}
        </span>
      </div>

      {/* Action Buttons: COPY, INSPECT, SELL NOW */}
      <div className="flex items-center gap-2 pt-1 border-t border-[var(--border)]">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onCopy(pos.token_address, pos.position_id);
          }}
          className="flex-1 py-1 rounded border border-[var(--border-bright)] bg-[var(--panel)] text-[var(--muted)] hover:text-[var(--teal)] hover:border-[var(--teal)] text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer"
        >
          {isCopied ? <Check size={11} className="text-[var(--green)]" /> : <Copy size={11} />}
          <span>{isCopied ? 'COPIED' : 'COPY'}</span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onInspect(pos.chain, pos.token_address);
          }}
          className="flex-1 py-1 rounded border border-[var(--border-bright)] bg-[var(--panel)] text-[var(--muted)] hover:text-[var(--blue)] hover:border-[var(--blue)] text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer"
        >
          <ExternalLink size={11} />
          <span>INSPECT</span>
        </button>

        <button
          onClick={(e) => {
            e.stopPropagation();
            onSell(pos.position_id);
          }}
          className="flex-1 py-1 rounded border border-[var(--red)] bg-[var(--red)]/10 text-[var(--red)] hover:bg-[var(--red)] hover:text-white font-bold text-[11px] transition-colors cursor-pointer"
        >
          SELL NOW
        </button>
      </div>
    </div>
  );
});

// ---------------- MEMOIZED QUICK STATS CARD ----------------
const QuickStatsCard = React.memo<{ stats: QuickStats }>(({ stats }) => {
  return (
    <div className="border-b border-[var(--border)] p-3">
      <div className="text-xs font-bold text-[var(--text)] mb-2 flex items-center justify-between">
        <span>QUICK STATS</span>
        <DollarSign size={13} className="text-[var(--teal)]" />
      </div>

      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">TOTAL CAPITAL</div>
          <div className="font-bold text-[var(--text)]">{formatUsd(stats.total_balance)}</div>
        </div>
        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">AVAILABLE CASH</div>
          <div className="font-bold text-[var(--teal)]">{formatUsd(stats.cash_balance)}</div>
        </div>

        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">INVESTED</div>
          <div className="font-bold text-[var(--text)]">{formatUsd(stats.invested_capital)}</div>
        </div>
        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">UNREALIZED P&L</div>
          <div className={`font-bold ${stats.unrealized_pnl >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {stats.unrealized_pnl >= 0 ? '+' : ''}{formatUsd(stats.unrealized_pnl)}
          </div>
        </div>

        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">REALIZED P&L</div>
          <div className={`font-bold ${stats.realized_pnl >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {stats.realized_pnl >= 0 ? '+' : ''}{formatUsd(stats.realized_pnl)}
          </div>
        </div>
        <div className="bg-[var(--card)] p-2 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase">WIN RATE</div>
          <div className="font-bold text-[var(--yellow)]">{stats.win_rate_pct}% ({stats.wins_count}W/{stats.losses_count}L)</div>
        </div>
      </div>
    </div>
  );
});

// ---------------- MEMOIZED EVENT LOG CARD ----------------
const EventLogCard = React.memo<{ logs: AppLog[] }>(({ logs }) => {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="h-[36px] px-3 bg-[var(--card)] border-b border-[var(--border)] flex items-center justify-between text-xs font-bold text-[var(--text)] select-none">
        <span>EVENT LOG</span>
        <span className="text-[10px] text-[var(--muted)] font-normal font-mono">{logs.length} events</span>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-1.5 text-xs font-mono">
        {logs.length === 0 ? (
          <div className="text-center text-[var(--dim)] py-6">No events logged</div>
        ) : (
          logs.map((log) => {
            let badgeColor = 'text-[var(--teal)]';
            if (log.severity === 'WARNING') badgeColor = 'text-[var(--yellow)]';
            if (log.severity === 'ERROR' || log.severity === 'CRITICAL') badgeColor = 'text-[var(--red)]';

            return (
              <div key={log.id} className="p-1.5 rounded bg-[var(--card)] border border-[var(--border)] flex flex-col gap-0.5">
                <div className="flex items-center justify-between text-[10px]">
                  <span className={`font-bold ${badgeColor}`}>[{log.type}]</span>
                  <span className="text-[var(--dim)]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                </div>
                <div className="text-[var(--text)] text-[11px] leading-tight break-words">{log.message}</div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
});

// ---------------- DASHBOARD VIEW CONTAINER ----------------
export const DashboardView: React.FC<DashboardViewProps> = ({
  positions,
  stats,
  logs,
  onSellPosition,
  onSellAll,
  onInspectToken,
}) => {
  const [selectedAddress, setSelectedAddress] = useState<string>(() =>
    positions.length > 0 ? positions[0].token_address : ''
  );
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = useCallback((text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  }, []);

  const handleSelectAddress = useCallback((addr: string) => {
    setSelectedAddress(addr);
  }, []);

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* LEFT AREA: 2-COLUMN OPEN POSITIONS CARDS */}
      <div className="flex-1 flex flex-col border-r border-[var(--border)] overflow-hidden">
        {/* Positions Header */}
        <div className="h-[40px] px-4 bg-[var(--panel)] border-b border-[var(--border)] flex items-center justify-between text-xs select-none">
          <div className="flex items-center gap-2">
            <span className="text-[var(--text)] font-bold">OPEN POSITIONS</span>
            <span className="text-[var(--teal)] font-bold">({positions.length})</span>
          </div>

          {positions.length > 0 && (
            <button
              onClick={onSellAll}
              className="px-2 py-0.5 rounded border border-[var(--red)] text-[var(--red)] hover:bg-[var(--red)]/10 text-xs font-semibold cursor-pointer transition-colors"
            >
              SELL ALL POSITIONS
            </button>
          )}
        </div>

        {/* Scrollable Cards Grid */}
        <div className="flex-1 overflow-y-auto p-3">
          {positions.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-[var(--muted)]">
              <ShieldCheck size={48} className="text-[var(--dim)] mb-3 opacity-60" />
              <p className="text-sm font-semibold text-[var(--text)] mb-1">NO OPEN POSITIONS</p>
              <p className="text-xs max-w-md text-[var(--muted)]">
                The Rug Defense & Strategy engine will evaluate tokens from the DexScreener universe scan. When all 9 security layers and trade filters pass, positions will appear here with live sub-second price updates.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              {positions.map((pos) => (
                <PositionCard
                  key={pos.position_id}
                  pos={pos}
                  isSelected={selectedAddress === pos.token_address}
                  isCopied={copiedId === pos.position_id}
                  onSelect={handleSelectAddress}
                  onCopy={handleCopy}
                  onInspect={onInspectToken}
                  onSell={onSellPosition}
                />
              ))}
            </div>
          )}
        </div>

        {/* Selected-Address Bar */}
        <div className="h-[36px] bg-[var(--panel)] border-t border-[var(--border)] px-4 flex items-center justify-between text-xs select-none">
          <div className="flex items-center gap-2 text-[var(--muted)] overflow-hidden">
            <span className="text-[var(--dim)] font-semibold shrink-0">SELECTED:</span>
            <span className="font-mono text-[var(--text)] truncate">
              {selectedAddress || 'None selected (click a position card)'}
            </span>
          </div>

          {selectedAddress && (
            <button
              onClick={() => handleCopy(selectedAddress, 'bar')}
              className="px-2 py-0.5 rounded border border-[var(--border-bright)] text-[var(--teal)] hover:bg-[var(--card)] text-xs flex items-center gap-1 cursor-pointer shrink-0"
            >
              {copiedId === 'bar' ? <Check size={11} className="text-[var(--green)]" /> : <Copy size={11} />}
              <span>{copiedId === 'bar' ? 'COPIED' : 'COPY ADDRESS'}</span>
            </button>
          )}
        </div>
      </div>

      {/* RIGHT COLUMN (340px): QUICK STATS & EVENT LOG */}
      <div className="w-[340px] flex flex-col bg-[var(--panel)] overflow-hidden">
        <QuickStatsCard stats={stats} />
        <EventLogCard logs={logs} />
      </div>
    </div>
  );
};
