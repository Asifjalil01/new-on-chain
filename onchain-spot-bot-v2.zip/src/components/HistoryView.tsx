import React from 'react';
import { Download, History, TrendingUp, TrendingDown } from 'lucide-react';
import { formatPrice, formatUsd } from '../utils/formatters';

interface TradeRecord {
  trade_id: string;
  chain: string;
  token_address: string;
  symbol: string;
  dex: string;
  entry_timestamp: number;
  exit_timestamp: number;
  entry_price_usd: number;
  exit_price_usd: number;
  quantity: number;
  cost_basis_usd: number;
  net_pnl_usd: number;
  net_pnl_percent: number;
  peak_profit_percent: number;
  exit_reason: string;
  holding_seconds: number;
}

interface HistoryViewProps {
  trades: TradeRecord[];
}

export const HistoryView: React.FC<HistoryViewProps> = ({ trades }) => {
  const totalNetPnl = trades.reduce((sum, t) => sum + t.net_pnl_usd, 0);
  const wins = trades.filter((t) => t.net_pnl_usd > 0).length;
  const winRate = trades.length > 0 ? (wins / trades.length) * 100 : 0;

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[var(--bg)] p-4 space-y-4">
      {/* Performance Summary Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TOTAL REALIZED P&L</div>
          <div className={`text-xl font-bold font-mono ${totalNetPnl >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {totalNetPnl >= 0 ? '+' : ''}{formatUsd(totalNetPnl)}
          </div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TOTAL CLOSED TRADES</div>
          <div className="text-xl font-bold text-[var(--text)] font-mono">{trades.length}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">WIN RATE</div>
          <div className="text-xl font-bold text-[var(--yellow)] font-mono">{winRate.toFixed(1)}% ({wins}W / {trades.length - wins}L)</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)] flex items-center justify-between">
          <div>
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TRADES RECORD</div>
            <div className="text-xs text-[var(--muted)] font-mono">trades_log.csv</div>
          </div>
          <a
            href="/api/export/trades_log.csv"
            download="trades_log.csv"
            className="px-3 py-1.5 rounded border border-[var(--teal)] bg-[var(--teal)] text-[var(--bg)] hover:brightness-110 text-xs flex items-center gap-1.5 cursor-pointer font-bold shadow-xs transition-all"
            title="Download full trades_log.csv containing all buy & sell records with realized fees & P&L"
          >
            <Download size={13} />
            <span>DOWNLOAD trades_log.csv</span>
          </a>
        </div>
      </div>

      {/* Trades Table */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 flex-1">
        <h3 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-3 tracking-wider flex items-center gap-2">
          <History size={14} className="text-[var(--teal)]" />
          <span>CLOSED POSITION EXECUTION LEDGER</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[var(--panel)] border-b border-[var(--border)] text-[10px] text-[var(--dim)] uppercase">
              <tr>
                <th className="p-2">DATE / TIME</th>
                <th className="p-2">TOKEN</th>
                <th className="p-2">CHAIN</th>
                <th className="p-2">DEX</th>
                <th className="p-2 text-right">ENTRY</th>
                <th className="p-2 text-right">EXIT</th>
                <th className="p-2 text-right">COST BASIS</th>
                <th className="p-2 text-right">NET P&L</th>
                <th className="p-2 text-right">PEAK %</th>
                <th className="p-2 text-center">EXIT REASON</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {trades.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-[var(--muted)]">
                    No closed trades recorded yet. Realized trades will appear here with net P&L and fees.
                  </td>
                </tr>
              ) : (
                trades.map((t) => {
                  const isProfit = t.net_pnl_usd >= 0;
                  return (
                    <tr key={t.trade_id} className="hover:bg-[var(--card-hover)]">
                      <td className="p-2 text-[var(--dim)]">{new Date(t.exit_timestamp).toLocaleString()}</td>
                      <td className="p-2 font-bold text-[var(--text)]">{t.symbol}</td>
                      <td className="p-2 text-[var(--muted)] uppercase">{t.chain}</td>
                      <td className="p-2 text-[var(--muted)] uppercase">{t.dex}</td>
                      <td className="p-2 text-right text-[var(--muted)]">{formatPrice(t.entry_price_usd)}</td>
                      <td className="p-2 text-right text-[var(--muted)]">{formatPrice(t.exit_price_usd)}</td>
                      <td className="p-2 text-right text-[var(--muted)]">{formatUsd(t.cost_basis_usd)}</td>
                      <td className={`p-2 text-right font-bold ${isProfit ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
                        {isProfit ? '+' : ''}{formatUsd(t.net_pnl_usd)} ({isProfit ? '+' : ''}{t.net_pnl_percent}%)
                      </td>
                      <td className="p-2 text-right text-[var(--teal)] font-bold">+{t.peak_profit_percent}%</td>
                      <td className="p-2 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] bg-[var(--panel)] border border-[var(--border)] text-[var(--muted)]">
                          {t.exit_reason}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
