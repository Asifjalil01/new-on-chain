import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, Check, X, Lock, CheckCircle2 } from 'lucide-react';
import { useBot } from '../context/BotContext';

export const LiveConfirmModal: React.FC = () => {
  const { isLiveConfirmOpen, setIsLiveConfirmOpen, confirmLiveMode, config } = useBot();
  const [confirmText, setConfirmText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isLiveConfirmOpen) return null;

  // Case-insensitive, whitespace-trimmed matching for robust validation
  const normalized = confirmText.trim().toUpperCase().replace(/\s+/g, ' ');
  const isMatch = normalized === 'ENABLE LIVE' || normalized === 'LIVE' || normalized === 'ENABLE';

  const handleConfirm = async () => {
    if (!isMatch || isSubmitting) return;
    setIsSubmitting(true);
    try {
      const ok = await confirmLiveMode();
      if (ok) {
        setConfirmText('');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setConfirmText('');
    setIsLiveConfirmOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 select-none">
      <div className="w-full max-w-lg bg-[var(--card)] border-2 border-[var(--red)] rounded shadow-2xl overflow-hidden flex flex-col font-mono text-xs">
        {/* Modal Header */}
        <div className="h-[48px] px-4 bg-[var(--red)]/20 border-b border-[var(--red)]/50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[var(--red)] font-bold tracking-wider">
            <ShieldAlert size={18} />
            <span>SWITCH TO LIVE ON-CHAIN EXECUTION</span>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded text-[var(--muted)] hover:text-white cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Warning Content */}
        <div className="p-4 space-y-3 bg-[var(--panel)]/40">
          <div className="p-3 bg-[var(--red)]/10 border border-[var(--red)]/30 rounded text-[var(--red)] flex items-start gap-2.5">
            <AlertTriangle size={18} className="shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">CAUTION: REAL CAPITAL ENGAGEMENT</p>
              <p className="text-[11px] leading-relaxed text-[var(--text)]">
                You are switching from paper simulation to <strong>LIVE MAINNET EXECUTION</strong>. Transactions will be broadcast directly to blockchain validators with real native gas and DEX liquidity outlays.
              </p>
            </div>
          </div>

          <div className="space-y-2 text-[11px] text-[var(--muted)] border-t border-[var(--border)] pt-3">
            <p className="font-semibold text-[var(--text)] uppercase">Mandatory Security Controls Applied:</p>
            <ul className="list-disc list-inside space-y-1 pl-1">
              <li>Bot will be <strong>STOPPED</strong> immediately to allow safe wallet configuration.</li>
              <li>Virtual paper hot vault is <strong>DEACTIVATED</strong> from active trading context.</li>
              <li>A real browser wallet (Phantom, MetaMask, Solflare) with sufficient balance must be connected.</li>
              <li>Bot will strictly refuse to start if no real wallet is connected or balance is 0.</li>
              <li>Per-trade size is capped at <strong>${config.MAX_POSITION_SIZE_USD || 100} USD</strong> with hard -8% stop loss.</li>
            </ul>
          </div>

          <div className="pt-2">
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-bold text-[var(--text)]">
                Type <span className="text-[var(--red)] font-mono font-bold">ENABLE LIVE</span> to confirm:
              </label>
              <button
                type="button"
                onClick={() => setConfirmText('ENABLE LIVE')}
                className="text-[10px] text-[var(--teal)] hover:underline cursor-pointer font-semibold"
              >
                [Auto-Fill]
              </button>
            </div>
            <div className="relative">
              <input
                type="text"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && isMatch) {
                    handleConfirm();
                  }
                }}
                placeholder="Type ENABLE LIVE or enable live"
                className={`w-full bg-[var(--bg)] border rounded px-3 py-2 text-xs font-mono uppercase tracking-wider outline-none transition-colors ${
                  isMatch
                    ? 'border-[var(--green)] text-[var(--green)] ring-1 ring-[var(--green)]/50'
                    : 'border-[var(--border-bright)] focus:border-[var(--red)] text-[var(--text)]'
                }`}
                autoFocus
              />
              {isMatch && (
                <div className="absolute right-2.5 top-2 flex items-center gap-1 text-[var(--green)] text-[10px] font-bold">
                  <CheckCircle2 size={13} />
                  <span>MATCHED</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions Footer */}
        <div className="p-3 bg-[var(--panel)] border-t border-[var(--border)] flex items-center justify-between">
          <button
            onClick={handleClose}
            className="px-4 py-1.5 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--text)] hover:bg-[var(--card-hover)] cursor-pointer text-xs"
          >
            CANCEL / STAY IN DRY RUN
          </button>

          <button
            onClick={handleConfirm}
            disabled={!isMatch || isSubmitting}
            className={`px-4 py-1.5 rounded font-bold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              isMatch && !isSubmitting
                ? 'bg-[var(--red)] text-white hover:brightness-110 shadow-md ring-1 ring-[var(--red)]/80 animate-pulse'
                : 'bg-[var(--card)] text-[var(--dim)] border border-[var(--border)] opacity-50 cursor-not-allowed'
            }`}
          >
            <Lock size={12} />
            <span>{isSubmitting ? 'SWITCHING...' : 'CONFIRM LIVE MODE'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
