import React from 'react';
import { ShieldCheck, ShieldAlert, AlertTriangle, FileText } from 'lucide-react';

interface LayerStat {
  layer: string;
  blocked: number;
  check: string;
}

interface RugDefenseData {
  total_audited: number;
  passed_count: number;
  blocked_count: number;
  honeypots_caught: number;
  false_negatives_count: number;
  layer_stats: LayerStat[];
  post_mortems: any[];
}

interface RugDefenseViewProps {
  defenseData: RugDefenseData | null;
}

export const RugDefenseView: React.FC<RugDefenseViewProps> = ({ defenseData }) => {
  if (!defenseData) {
    return (
      <div className="flex-1 flex items-center justify-center text-xs text-[var(--muted)]">
        Loading Rug Defense filter metrics...
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[var(--bg)] p-4 space-y-4">
      {/* High-level Counters */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TOTAL TOKENS AUDITED</div>
          <div className="text-xl font-bold text-[var(--text)] font-mono">{defenseData.total_audited}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">PASSED ALL LAYERS</div>
          <div className="text-xl font-bold text-[var(--green)] font-mono">{defenseData.passed_count}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">BLOCKED AS UNVERIFIED/RISK</div>
          <div className="text-xl font-bold text-[var(--red)] font-mono">{defenseData.blocked_count}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">HONEYPOTS INTERCEPTED</div>
          <div className="text-xl font-bold text-[var(--red)] font-mono">{defenseData.honeypots_caught}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">FALSE NEGATIVES (POST-MORTEM)</div>
          <div className="text-xl font-bold text-[var(--teal)] font-mono">{defenseData.false_negatives_count}</div>
        </div>
      </div>

      {/* Layer-by-Layer Breakdown */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4">
        <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-3 tracking-wider flex items-center gap-2">
          <ShieldAlert size={14} className="text-[var(--teal)]" />
          <span>RUG DEFENSE LAYERS (L1 - L9) FILTER PERFORMANCE</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[var(--panel)] border-b border-[var(--border)] text-[10px] text-[var(--dim)] uppercase">
              <tr>
                <th className="p-2">LAYER</th>
                <th className="p-2">SECURITY CRITERIA</th>
                <th className="p-2 text-right">TOKENS BLOCKED</th>
                <th className="p-2 text-center">ENFORCEMENT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {defenseData.layer_stats.map((ls) => (
                <tr key={ls.layer} className="hover:bg-[var(--card-hover)]">
                  <td className="p-2 font-bold text-[var(--text)]">{ls.layer}</td>
                  <td className="p-2 text-[var(--muted)]">{ls.check}</td>
                  <td className="p-2 text-right font-bold text-[var(--red)]">{ls.blocked}</td>
                  <td className="p-2 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-[var(--red)]/10 text-[var(--red)] border border-[var(--red)]/30 font-bold">
                      FAIL-CLOSED
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Post-Mortem Audit List */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4">
        <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 mb-2 tracking-wider flex items-center gap-2">
          <FileText size={14} className="text-[var(--teal)]" />
          <span>POST-MORTEM FALSE NEGATIVE AUDIT LOG</span>
        </h2>
        <p className="text-xs text-[var(--muted)]">
          {defenseData.post_mortems.length === 0
            ? 'Zero false negatives recorded. If any token passes the 9-layer defense and subsequently suffers an unannounced liquidity drain or malicious upgrade, it will be listed here with a full forensic post-mortem and configuration recommendation.'
            : `${defenseData.post_mortems.length} post-mortems logged.`}
        </p>
      </div>
    </div>
  );
};
