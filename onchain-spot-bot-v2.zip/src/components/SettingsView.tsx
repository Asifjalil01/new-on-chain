import React, { useState } from 'react';
import { Settings, Save, Plus, Trash2, Shield, Lock, Sliders, Download, Terminal, Filter, RefreshCw, Zap } from 'lucide-react';

interface TrailingTier {
  threshold: number;
  drop: number;
}

interface SettingsViewProps {
  config: any;
  onSaveConfig: (updatedConfig: any) => Promise<boolean>;
  onOpenWalletModal?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ config, onSaveConfig, onOpenWalletModal }) => {
  const [formData, setFormData] = useState({
    APP_NAME: config.APP_NAME || 'On-Chain SPOT Bot v2.1.1',
    DEFAULT_CHAIN: config.DEFAULT_CHAIN || 'solana',
    EXECUTION_MODE: config.EXECUTION_MODE || 'paper',
    TOTAL_CAPITAL_USD: config.TOTAL_CAPITAL_USD || 1600.0,
    MAX_POSITIONS: config.MAX_POSITIONS || 5,
    MAX_POSITION_SIZE_USD: config.MAX_POSITION_SIZE_USD || 100.0,
    TRADE_ALLOCATION_AMOUNT: config.TRADE_ALLOCATION_AMOUNT || 0.005,
    TRADE_ALLOCATION_CURRENCY: config.TRADE_ALLOCATION_CURRENCY || 'SOL',
    MIN_GAS_RESERVE_SOL: config.MIN_GAS_RESERVE_SOL || 0.02,
    MIN_GAS_RESERVE_ETH: config.MIN_GAS_RESERVE_ETH || 0.005,
    PRIORITY_FEE_LEVEL: config.PRIORITY_FEE_LEVEL || 'standard',
    ACTIVE_WALLET_ID: config.ACTIVE_WALLET_ID || 'paper',
    SELL_COOLDOWN_MINUTES: config.SELL_COOLDOWN_MINUTES || 30,

    // QUANTITATIVE HARD PRE-FILTER CONSTRAINTS
    MIN_LIQUIDITY_USD: config.MIN_LIQUIDITY_USD || 25000.0,
    MIN_VOLUME_24H_USD: config.MIN_VOLUME_24H_USD || 50000.0,
    MIN_TXNS_24H: config.MIN_TXNS_24H || 200,
    MIN_TRADERS_24H: config.MIN_TRADERS_24H || 100,
    MIN_AGE_MINUTES: config.MIN_AGE_MINUTES || 30,
    MAX_AGE_DAYS: config.MAX_AGE_DAYS || 365,
    MAX_FDV_LIQUIDITY_RATIO: config.MAX_FDV_LIQUIDITY_RATIO || 100.0,
    MAX_VOLUME_LIQUIDITY_RATIO: config.MAX_VOLUME_LIQUIDITY_RATIO || 40.0,
    MAX_PRICE_IMPACT_PCT: config.MAX_PRICE_IMPACT_PCT || 2.0,

    // POSITION RISK & ROTATION
    ENABLE_STOP_LOSS: config.ENABLE_STOP_LOSS !== false,
    STOP_LOSS_PCT: config.STOP_LOSS_PCT || -8.0,
    ENABLE_MAX_HOLDING_TIME: config.ENABLE_MAX_HOLDING_TIME !== false,
    MAX_HOLDING_HOURS: config.MAX_HOLDING_HOURS || 4.0,
    ENABLE_SLOT_ROTATION: config.ENABLE_SLOT_ROTATION !== false,
    ROTATION_MIN_SCORE: config.ROTATION_MIN_SCORE || 85,
    ROTATION_MIN_HOLDING_MINUTES: config.ROTATION_MIN_HOLDING_MINUTES || 15,
    SCAN_INTERVAL_SECONDS: config.SCAN_INTERVAL_SECONDS || 30,

    MIN_PRICE_USD: config.MIN_PRICE_USD || 0.00000001,
    MAX_PRICE_USD: config.MAX_PRICE_USD || 100000.0,
    WATCH_NEW_PAIRS: config.WATCH_NEW_PAIRS !== false,
    ENABLE_LIVE_MARKET_DATA: config.ENABLE_LIVE_MARKET_DATA !== false,
    TRAILING_TIERS: config.TRAILING_TIERS || [],
    GOPLUS_API_KEY: config.GOPLUS_API_KEY || '',
    RUGCHECK_API_KEY: config.RUGCHECK_API_KEY || '',
  });

  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const chains = ['solana', 'base', 'ethereum', 'bsc', 'arbitrum', 'polygon', 'avalanche', 'optimism'];

  const handleTierChange = (index: number, field: 'threshold' | 'drop', value: number) => {
    const updated = [...formData.TRAILING_TIERS];
    updated[index] = { ...updated[index], [field]: value };
    setFormData({ ...formData, TRAILING_TIERS: updated });
  };

  const handleAddTier = () => {
    const lastTier = formData.TRAILING_TIERS[formData.TRAILING_TIERS.length - 1];
    const newThreshold = lastTier ? lastTier.threshold + 20 : 5;
    const newDrop = lastTier ? lastTier.drop + 1 : 1;
    setFormData({
      ...formData,
      TRAILING_TIERS: [...formData.TRAILING_TIERS, { threshold: newThreshold, drop: newDrop }],
    });
  };

  const handleDeleteTier = (index: number) => {
    if (formData.TRAILING_TIERS.length <= 1) return;
    const updated = formData.TRAILING_TIERS.filter((_: any, i: number) => i !== index);
    setFormData({ ...formData, TRAILING_TIERS: updated });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveMessage(null);
    try {
      const success = await onSaveConfig(formData);
      if (success) {
        setSaveMessage('Settings validated and saved successfully.');
      } else {
        setSaveMessage('Validation error saving settings.');
      }
    } catch (err: any) {
      setSaveMessage(`Error: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-y-auto bg-[var(--bg)] p-4 space-y-4 text-xs">
      {/* Header and Save Button */}
      <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
        <div className="flex items-center gap-2">
          <Settings size={16} className="text-[var(--teal)]" />
          <h1 className="text-sm font-bold text-[var(--text)] tracking-wider">SYSTEM CONFIGURATION & QUANTITATIVE RISK ENGINE</h1>
        </div>

        <button
          type="submit"
          disabled={isSaving}
          className="px-4 py-1.5 rounded font-bold border border-[var(--teal)] bg-[var(--teal)] text-[var(--bg)] hover:brightness-110 flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
        >
          <Save size={13} />
          <span>{isSaving ? 'VALIDATING...' : 'SAVE SETTINGS'}</span>
        </button>
      </div>

      {saveMessage && (
        <div className="p-3 bg-[var(--teal)]/10 border border-[var(--teal)] rounded text-[var(--teal)] font-mono">
          {saveMessage}
        </div>
      )}

      {/* DOWNLOAD STANDALONE PROJECT PACKAGE */}
      <div className="bg-[var(--card)] border border-[var(--teal)]/40 rounded p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-sm font-bold text-[var(--teal)]">
            <Download size={16} />
            <span>DOWNLOAD COMPLETE APPLICATION (.ZIP)</span>
          </div>
          <p className="text-xs text-[var(--muted)] max-w-2xl leading-relaxed">
            Download the entire codebase with the exact same GUI and live DexScreener + GeckoTerminal scanning. Includes 1-click startup scripts (<code className="text-[var(--text)]">start.bat</code> for Windows, <code className="text-[var(--text)]">start.sh</code> for Mac/Linux), full Python engine, SQLite database, and test suite.
          </p>
        </div>

        <a
          href="/api/download-project"
          download="onchain-spot-bot-v2.zip"
          className="px-4 py-2 rounded font-bold border border-[var(--teal)] bg-[var(--teal)] text-[var(--bg)] hover:brightness-110 flex items-center gap-2 cursor-pointer shadow-sm transition-all whitespace-nowrap"
        >
          <Download size={14} />
          <span>DOWNLOAD ZIP (~180 KB)</span>
        </a>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* 1. GENERAL & POSITION SIZING */}
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 space-y-3">
          <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 tracking-wider flex items-center gap-1.5">
            <Sliders size={13} className="text-[var(--teal)]" />
            <span>GENERAL & SIZING CONSTRAINTS</span>
          </h2>

          <div className="space-y-2">
            <div>
              <label className="block text-[var(--dim)] uppercase font-semibold mb-1">EXECUTION MODE</label>
              <select
                value={formData.EXECUTION_MODE}
                onChange={(e) => setFormData({ ...formData, EXECUTION_MODE: e.target.value })}
                className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] focus:border-[var(--teal)] cursor-pointer"
              >
                <option value="paper">PAPER (Dry-Run on Live Feeds)</option>
                <option value="testnet">TESTNET (Devnet / Testnet)</option>
                <option value="mainnet">MAINNET (Live Trading)</option>
              </select>
            </div>

            <div>
              <label className="block text-[var(--dim)] uppercase font-semibold mb-1">DEFAULT BLOCKCHAIN</label>
              <select
                value={formData.DEFAULT_CHAIN}
                onChange={(e) => setFormData({ ...formData, DEFAULT_CHAIN: e.target.value })}
                className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] focus:border-[var(--teal)] cursor-pointer uppercase"
              >
                {chains.map((c) => (
                  <option key={c} value={c}>
                    {c.toUpperCase()}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">TOTAL CAPITAL (USD)</label>
                <input
                  type="number"
                  value={formData.TOTAL_CAPITAL_USD}
                  onChange={(e) => setFormData({ ...formData, TOTAL_CAPITAL_USD: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MAX POSITION SLOTS</label>
                <input
                  type="number"
                  value={formData.MAX_POSITIONS}
                  onChange={(e) => setFormData({ ...formData, MAX_POSITIONS: parseInt(e.target.value) || 1 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MAX POSITION SIZE (USD)</label>
                <input
                  type="number"
                  value={formData.MAX_POSITION_SIZE_USD}
                  onChange={(e) => setFormData({ ...formData, MAX_POSITION_SIZE_USD: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">SCAN INTERVAL (SECONDS)</label>
                <input
                  type="number"
                  value={formData.SCAN_INTERVAL_SECONDS}
                  onChange={(e) => setFormData({ ...formData, SCAN_INTERVAL_SECONDS: parseInt(e.target.value) || 30 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 2. QUANTITATIVE PRE-FILTER REJECT RULES */}
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 space-y-3">
          <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 tracking-wider flex items-center gap-1.5">
            <Filter size={13} className="text-[var(--red)]" />
            <span>QUANTITATIVE HARD PRE-FILTER THRESHOLDS</span>
          </h2>

          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN LIQUIDITY ($)</label>
                <input
                  type="number"
                  value={formData.MIN_LIQUIDITY_USD}
                  onChange={(e) => setFormData({ ...formData, MIN_LIQUIDITY_USD: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Rejects pools under this depth</span>
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN 24H VOLUME ($)</label>
                <input
                  type="number"
                  value={formData.MIN_VOLUME_24H_USD}
                  onChange={(e) => setFormData({ ...formData, MIN_VOLUME_24H_USD: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Rejects dead/illiquid pairs</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN 24H TRANSACTIONS</label>
                <input
                  type="number"
                  value={formData.MIN_TXNS_24H}
                  onChange={(e) => setFormData({ ...formData, MIN_TXNS_24H: parseInt(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Buys + Sells combined</span>
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN ESTIMATED TRADERS</label>
                <input
                  type="number"
                  value={formData.MIN_TRADERS_24H}
                  onChange={(e) => setFormData({ ...formData, MIN_TRADERS_24H: parseInt(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Filters single-actor bot pools</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN MATURITY AGE (MINUTES)</label>
                <input
                  type="number"
                  value={formData.MIN_AGE_MINUTES}
                  onChange={(e) => setFormData({ ...formData, MIN_AGE_MINUTES: parseInt(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Anti-sniper protection period</span>
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MAX VOL/LIQ WASH RATIO</label>
                <input
                  type="number"
                  value={formData.MAX_VOLUME_LIQUIDITY_RATIO}
                  onChange={(e) => setFormData({ ...formData, MAX_VOLUME_LIQUIDITY_RATIO: parseFloat(e.target.value) || 0 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
                <span className="text-[9px] text-[var(--dim)]">Rejects wash-churned pools</span>
              </div>
            </div>
          </div>
        </div>

        {/* 3. TRADE AMOUNT & CAPITAL ALLOCATION */}
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 space-y-3">
          <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 tracking-wider flex items-center gap-1.5">
            <Shield size={13} className="text-[var(--teal)]" />
            <span>TRADE CAPITAL ALLOCATION & GAS RESERVE</span>
          </h2>

          <div className="space-y-3">
            <div>
              <label className="block text-[var(--dim)] uppercase font-semibold mb-1">PER-TRADE ALLOCATION AMOUNT</label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  step="any"
                  value={formData.TRADE_ALLOCATION_AMOUNT}
                  onChange={(e) => setFormData({ ...formData, TRADE_ALLOCATION_AMOUNT: parseFloat(e.target.value) || 0.001 })}
                  className="w-2/3 bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono font-bold"
                />
                <select
                  value={formData.TRADE_ALLOCATION_CURRENCY}
                  onChange={(e) => setFormData({ ...formData, TRADE_ALLOCATION_CURRENCY: e.target.value })}
                  className="w-1/3 bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2 py-1.5 text-[var(--teal)] font-bold cursor-pointer"
                >
                  <option value="SOL">SOL</option>
                  <option value="ETH">ETH</option>
                  <option value="BNB">BNB</option>
                  <option value="USDT">USDT</option>
                  <option value="USDC">USDC</option>
                  <option value="USD">USD</option>
                </select>
              </div>
              <span className="text-[10px] text-[var(--dim)] mt-0.5 block">
                The bot uses approximately this amount and never intentionally exceeds it.
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN GAS RESERVE (SOL)</label>
                <input
                  type="number"
                  step="0.001"
                  value={formData.MIN_GAS_RESERVE_SOL}
                  onChange={(e) => setFormData({ ...formData, MIN_GAS_RESERVE_SOL: parseFloat(e.target.value) || 0.01 })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
                />
              </div>
              <div>
                <label className="block text-[var(--dim)] uppercase font-semibold mb-1">PRIORITY FEE LEVEL</label>
                <select
                  value={formData.PRIORITY_FEE_LEVEL}
                  onChange={(e) => setFormData({ ...formData, PRIORITY_FEE_LEVEL: e.target.value })}
                  className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] cursor-pointer uppercase"
                >
                  <option value="standard">Standard</option>
                  <option value="high">High</option>
                  <option value="ultra">Ultra Fast</option>
                </select>
              </div>
            </div>

            {onOpenWalletModal && (
              <div className="pt-2 border-t border-[var(--border)]">
                <button
                  type="button"
                  onClick={onOpenWalletModal}
                  className="w-full py-1.5 px-3 rounded border border-[var(--teal)] bg-[var(--panel)] text-[var(--teal)] hover:bg-[var(--teal)]/10 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <span>CONNECT / SELECT ACTIVE WALLET</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* 4. POSITION LIFECYCLE & SLOT ROTATION */}
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 space-y-3">
          <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 tracking-wider flex items-center gap-1.5">
            <Zap size={13} className="text-[var(--yellow)]" />
            <span>POSITION MANAGEMENT & SLOT ROTATION</span>
          </h2>

          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* STOP LOSS BLOCK */}
              <div className="p-2.5 rounded border border-[var(--border)] bg-[var(--panel)]/40 flex flex-col justify-between gap-2">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={formData.ENABLE_STOP_LOSS}
                      onChange={(e) => setFormData({ ...formData, ENABLE_STOP_LOSS: e.target.checked })}
                      className="rounded text-[var(--teal)] focus:ring-0"
                    />
                    <span className="font-bold text-xs text-[var(--text)]">ENABLE STOP LOSS</span>
                  </label>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border ${formData.ENABLE_STOP_LOSS ? 'border-[var(--green)]/40 text-[var(--green)] bg-[var(--green)]/10' : 'border-[var(--muted)]/40 text-[var(--muted)]'}`}>
                    {formData.ENABLE_STOP_LOSS ? 'ACTIVE' : 'DISABLED'}
                  </span>
                </div>
                <div>
                  <label className="block text-[10px] text-[var(--dim)] uppercase font-semibold mb-1">STOP LOSS DRAWDOWN (%)</label>
                  <input
                    type="number"
                    step="0.5"
                    disabled={!formData.ENABLE_STOP_LOSS}
                    value={formData.STOP_LOSS_PCT}
                    onChange={(e) => setFormData({ ...formData, STOP_LOSS_PCT: parseFloat(e.target.value) || -8.0 })}
                    className={`w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--red)] font-mono font-bold ${!formData.ENABLE_STOP_LOSS ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                  <span className="text-[9px] text-[var(--dim)]">
                    {formData.ENABLE_STOP_LOSS ? 'Exits positions when price drawdown reaches this percentage.' : 'Stop loss disabled: bot will hold through drawdowns.'}
                  </span>
                </div>
              </div>

              {/* MAX HOLDING TIME BLOCK */}
              <div className="p-2.5 rounded border border-[var(--border)] bg-[var(--panel)]/40 flex flex-col justify-between gap-2">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={formData.ENABLE_MAX_HOLDING_TIME}
                      onChange={(e) => setFormData({ ...formData, ENABLE_MAX_HOLDING_TIME: e.target.checked })}
                      className="rounded text-[var(--teal)] focus:ring-0"
                    />
                    <span className="font-bold text-xs text-[var(--text)]">ENABLE MAX HOLDING TIME</span>
                  </label>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border ${formData.ENABLE_MAX_HOLDING_TIME ? 'border-[var(--green)]/40 text-[var(--green)] bg-[var(--green)]/10' : 'border-[var(--muted)]/40 text-[var(--muted)]'}`}>
                    {formData.ENABLE_MAX_HOLDING_TIME ? 'ACTIVE' : 'DISABLED'}
                  </span>
                </div>
                <div>
                  <label className="block text-[10px] text-[var(--dim)] uppercase font-semibold mb-1">MAX HOLDING TIME (HOURS)</label>
                  <input
                    type="number"
                    step="0.5"
                    disabled={!formData.ENABLE_MAX_HOLDING_TIME}
                    value={formData.MAX_HOLDING_HOURS}
                    onChange={(e) => setFormData({ ...formData, MAX_HOLDING_HOURS: parseFloat(e.target.value) || 4.0 })}
                    className={`w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono ${!formData.ENABLE_MAX_HOLDING_TIME ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                  <span className="text-[9px] text-[var(--dim)]">
                    {formData.ENABLE_MAX_HOLDING_TIME ? 'Exits stagnant positions lacking breakout momentum after time limit.' : 'Max holding time disabled: positions will remain open indefinitely.'}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-[var(--border)]">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.ENABLE_SLOT_ROTATION}
                  onChange={(e) => setFormData({ ...formData, ENABLE_SLOT_ROTATION: e.target.checked })}
                  className="rounded text-[var(--teal)] focus:ring-0"
                />
                <span className="font-bold text-[var(--text)]">ENABLE SLOT ROTATION</span>
              </label>
              <p className="text-[10px] text-[var(--muted)] mt-1">
                When all 5 position slots are filled, automatically rotates the weakest stagnant slot if a higher-scoring runner is discovered.
              </p>
            </div>

            <div>
              <label className="block text-[var(--dim)] uppercase font-semibold mb-1">MIN ROTATION SCORE THRESHOLD</label>
              <input
                type="number"
                value={formData.ROTATION_MIN_SCORE}
                onChange={(e) => setFormData({ ...formData, ROTATION_MIN_SCORE: parseInt(e.target.value) || 85 })}
                className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded px-2.5 py-1.5 text-[var(--text)] font-mono"
              />
              <span className="text-[9px] text-[var(--dim)]">Candidate score must be &gt;= this to trigger slot rotation</span>
            </div>
          </div>
        </div>
      </div>

      {/* 5. TRAILING PROFIT TIERS TABLE */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
          <h2 className="text-xs font-bold text-[var(--text)] tracking-wider">
            STEPPED TRAILING PROFIT TIERS & LADDER
          </h2>
          <button
            type="button"
            onClick={handleAddTier}
            className="px-2 py-1 rounded border border-[var(--teal)] bg-[var(--panel)] text-[var(--teal)] hover:bg-[var(--teal)]/10 font-bold text-[10px] flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Plus size={11} />
            <span>ADD TIER</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
          {formData.TRAILING_TIERS.map((tier: TrailingTier, i: number) => (
            <div key={i} className="flex items-center gap-2 bg-[var(--panel)] p-2 rounded border border-[var(--border)]">
              <span className="text-[10px] font-bold text-[var(--dim)] font-mono w-6">#{i + 1}</span>
              <div className="flex items-center gap-1 flex-1">
                <span className="text-[10px] text-[var(--dim)]">GAIN &gt;=</span>
                <input
                  type="number"
                  step="0.1"
                  value={tier.threshold}
                  onChange={(e) => handleTierChange(i, 'threshold', parseFloat(e.target.value) || 0)}
                  className="w-14 bg-[var(--card)] border border-[var(--border-bright)] focus:border-[var(--teal)] rounded px-1 py-0.5 text-xs text-[var(--text)] font-mono text-center outline-none"
                />
                <span className="text-[10px] text-[var(--dim)]">%</span>
              </div>
              <div className="flex items-center gap-1 flex-1">
                <span className="text-[10px] text-[var(--dim)]">DROP</span>
                <input
                  type="number"
                  step="0.1"
                  value={tier.drop}
                  onChange={(e) => handleTierChange(i, 'drop', parseFloat(e.target.value) || 0)}
                  className="w-14 bg-[var(--card)] border border-[var(--border-bright)] focus:border-[var(--teal)] rounded px-1 py-0.5 text-xs text-[var(--text)] font-mono text-center outline-none"
                />
                <span className="text-[10px] text-[var(--dim)]">%</span>
              </div>
              <button
                type="button"
                onClick={() => handleDeleteTier(i)}
                className="text-[var(--red)] hover:opacity-80 p-1 cursor-pointer"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </form>
  );
};
