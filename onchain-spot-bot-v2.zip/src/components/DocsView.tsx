import React, { useState } from 'react';
import { FileText, Shield, Layers, BookOpen } from 'lucide-react';

export const DocsView: React.FC = () => {
  const [activeDoc, setActiveDoc] = useState<'AUDIT' | 'PROVIDERS' | 'COVERAGE' | 'STRATEGY'>('AUDIT');

  return (
    <div className="flex-1 flex overflow-hidden bg-[var(--bg)]">
      {/* Sidebar Doc Navigation */}
      <div className="w-[220px] bg-[var(--panel)] border-r border-[var(--border)] p-3 flex flex-col gap-1 text-xs select-none">
        <div className="text-[10px] text-[var(--dim)] uppercase font-semibold mb-2">SYSTEM DOCUMENTATION</div>

        <button
          onClick={() => setActiveDoc('AUDIT')}
          className={`flex items-center gap-2 px-2.5 py-1.5 rounded border text-left cursor-pointer transition-colors ${
            activeDoc === 'AUDIT'
              ? 'border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] font-bold'
              : 'border-transparent text-[var(--muted)] hover:text-[var(--text)]'
          }`}
        >
          <Shield size={13} />
          <span>AUDIT REPORT</span>
        </button>

        <button
          onClick={() => setActiveDoc('PROVIDERS')}
          className={`flex items-center gap-2 px-2.5 py-1.5 rounded border text-left cursor-pointer transition-colors ${
            activeDoc === 'PROVIDERS'
              ? 'border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] font-bold'
              : 'border-transparent text-[var(--muted)] hover:text-[var(--text)]'
          }`}
        >
          <BookOpen size={13} />
          <span>API PROVIDERS</span>
        </button>

        <button
          onClick={() => setActiveDoc('COVERAGE')}
          className={`flex items-center gap-2 px-2.5 py-1.5 rounded border text-left cursor-pointer transition-colors ${
            activeDoc === 'COVERAGE'
              ? 'border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] font-bold'
              : 'border-transparent text-[var(--muted)] hover:text-[var(--text)]'
          }`}
        >
          <Layers size={13} />
          <span>COVERAGE FEASIBILITY</span>
        </button>

        <button
          onClick={() => setActiveDoc('STRATEGY')}
          className={`flex items-center gap-2 px-2.5 py-1.5 rounded border text-left cursor-pointer transition-colors ${
            activeDoc === 'STRATEGY'
              ? 'border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] font-bold'
              : 'border-transparent text-[var(--muted)] hover:text-[var(--text)]'
          }`}
        >
          <FileText size={13} />
          <span>STRATEGY & SCORING</span>
        </button>
      </div>

      {/* Main Document Content Viewport */}
      <div className="flex-1 overflow-y-auto p-6 font-mono text-xs leading-relaxed text-[var(--text)]">
        {activeDoc === 'AUDIT' && (
          <div className="space-y-4 max-w-4xl">
            <h1 className="text-base font-bold text-[var(--teal)] border-b border-[var(--border)] pb-2">
              AUDIT REPORT: DEFECT CONFIRMATION & v2 REBUILD
            </h1>
            <p className="text-[var(--muted)]">
              This audit documents the 10 structural defects verified in the legacy v1 bot codebase and establishes the architectural fixes implemented in v2.
            </p>
            <div className="space-y-3">
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
                <span className="font-bold text-[var(--red)]">1. Mock Security & Fake Fills:</span>
                <p className="text-[var(--muted)] mt-1">
                  v1 used hash + random() in MockSecurityProvider. In v2, a real 9-layer Rug Defense engine conducts live honeypot simulation, LP lock inspection, and mint/freeze authority checks.
                </p>
              </div>
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
                <span className="font-bold text-[var(--red)]">2. Decision Pipeline Bypass:</span>
                <p className="text-[var(--muted)] mt-1">
                  v1 executed buys whenever item[&quot;tradeable&quot;] was true. v2 enforces a strict linear pipeline: Discovery -&gt; Data Validation -&gt; Security -&gt; Risk -&gt; Strategy -&gt; Simulation -&gt; Execution.
                </p>
              </div>
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--red)]/40">
                <span className="font-bold text-[var(--yellow)]">3. Trailing Profit Gap-Down Handling:</span>
                <p className="text-[var(--muted)] mt-1">
                  v1 erased peaks on sudden drawdowns. v2 preserves the peak, transitions into RECOVERY_WATCH, and exits only upon return to net breakeven.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeDoc === 'PROVIDERS' && (
          <div className="space-y-4 max-w-4xl">
            <h1 className="text-base font-bold text-[var(--teal)] border-b border-[var(--border)] pb-2">
              OFFICIAL API PROVIDERS & RATE LIMIT DIRECTORY
            </h1>
            <div className="space-y-3">
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
                <div className="font-bold text-[var(--text)]">DexScreener Public API (Primary Market Data)</div>
                <div className="text-[var(--dim)] mt-0.5">https://api.dexscreener.com (300 req/min limit)</div>
                <p className="text-[var(--muted)] mt-1">
                  Batch token queries: up to 30 addresses per request (/tokens/v1/&#123;chainId&#125;/&#123;addresses&#125;), yielding up to 9,000 token refreshes per minute.
                </p>
              </div>
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
                <div className="font-bold text-[var(--text)]">GoPlus Security API (Contract Static Analysis)</div>
                <div className="text-[var(--dim)] mt-0.5">https://api.gopluslabs.io/api/v1 (30 req/sec)</div>
                <p className="text-[var(--muted)] mt-1">
                  Evaluates arbitrary minting, owner balance modification, blacklists, and buy/sell tax configurations.
                </p>
              </div>
              <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
                <div className="font-bold text-[var(--text)]">RugCheck API (Solana Authority & LP Status)</div>
                <div className="text-[var(--dim)] mt-0.5">https://api.rugcheck.xyz/v1 (60 req/min)</div>
                <p className="text-[var(--muted)] mt-1">
                  Verifies mint authority revocation, freeze authority revocation, and LP burn status on Raydium/Orca.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeDoc === 'COVERAGE' && (
          <div className="space-y-4 max-w-4xl">
            <h1 className="text-base font-bold text-[var(--teal)] border-b border-[var(--border)] pb-2">
              COVERAGE FEASIBILITY & MATHEMATICAL MODEL
            </h1>
            <p className="text-[var(--muted)]">
              Throughput analysis for continuous universe auditing using 70% rate budget allocation:
            </p>
            <div className="bg-[var(--card)] p-4 rounded border border-[var(--border)] space-y-2">
              <div className="text-[var(--teal)] font-bold">Throughput Calculation:</div>
              <div>210 req/min allocated to sweeps × 30 tokens/request = 6,300 tokens/minute</div>
              <div>6,300 tokens/min × 60 minutes = 378,000 token refreshes/hour</div>
              <div className="text-[var(--yellow)] pt-2 border-t border-[var(--border)]">
                50,000 active tokens are refreshed every 7.9 minutes without exceeding public rate limits.
              </div>
            </div>
          </div>
        )}

        {activeDoc === 'STRATEGY' && (
          <div className="space-y-4 max-w-4xl">
            <h1 className="text-base font-bold text-[var(--teal)] border-b border-[var(--border)] pb-2">
              QUANTITATIVE STRATEGY, SCORING & EXPLAINABILITY
            </h1>
            <div className="bg-[var(--card)] p-4 rounded border border-[var(--border)] space-y-2">
              <div className="font-bold text-[var(--text)]">Quality Score Formula (0 - 100):</div>
              <div className="text-[var(--muted)]">
                Q = 0.30·S_security + 0.25·S_liquidity + 0.15·S_holders + 0.15·S_contract + 0.15·S_age
              </div>
              <div className="text-[var(--red)] text-[11px]">
                Rule: Any critical security failure (honeypot, active mint/freeze, sell tax &gt; 3%) forces Q = 0.
              </div>
            </div>

            <div className="bg-[var(--card)] p-4 rounded border border-[var(--border)] space-y-2">
              <div className="font-bold text-[var(--text)]">Trade Score Formula (0 - 100):</div>
              <div className="text-[var(--muted)]">
                T = 0.30·M_momentum + 0.25·V_pressure + 0.20·L_depth + 0.15·S_structure + 0.10·R_regime
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
