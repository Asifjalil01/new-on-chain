import React, { useState, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, ExternalLink, Copy, Check, ArrowLeft, TrendingUp, DollarSign, RefreshCw, Activity, Layers, Info } from 'lucide-react';
import { formatPrice, formatUsd, formatTimeAgo } from '../utils/formatters';
import { FeeCalculator } from '../fees/FeeCalculator';
import { FeeBreakdownCard } from './FeeBreakdownCard';
import { useBot } from '../context/BotContext';

interface UniverseToken {
  chain: string;
  token_address: string;
  pair_address: string;
  symbol: string;
  name: string;
  dex: string;
  quote_token?: string;
  quote_address?: string;
  price_usd: number;
  price_native?: number;
  price_source?: string;
  price_updated_at?: number;
  reference_price_usd?: number;
  expected_execution_price_usd?: number;
  price_impact_pct?: number;
  decimals?: number;
  liquidity_usd: number;
  volume_24h_usd: number;
  fdv_usd?: number;
  market_cap_usd?: number;
  price_change_1h: number;
  price_change_24h: number;
  txns_24h_buys: number;
  txns_24h_sells: number;
  pair_created_at_ms: number;
  state: string;
  quality_score: number;
  trade_score: number;
  risk_level: string;
  reasons: string[];
  warnings: string[];
  security?: any;
}

interface TokenDetailViewProps {
  token: UniverseToken | null;
  onBack: () => void;
  onPaperBuy: (token: UniverseToken) => void;
}

export const TokenDetailView: React.FC<TokenDetailViewProps> = ({
  token,
  onBack,
  onPaperBuy,
}) => {
  const { activeWallet, config } = useBot();
  const [copied, setCopied] = useState(false);
  const [copiedPair, setCopiedPair] = useState(false);
  const [timeframe, setTimeframe] = useState<'1H' | '6H' | '24H'>('24H');
  const [isVerifyingPrice, setIsVerifyingPrice] = useState(false);
  const [marketDebugData, setMarketDebugData] = useState<any | null>(null);

  const fetchLiveMarketPrice = async () => {
    if (!token) return;
    setIsVerifyingPrice(true);
    try {
      const res = await fetch(
        `/api/market-price?chain=${encodeURIComponent(token.chain)}&address=${encodeURIComponent(token.token_address)}&pair=${encodeURIComponent(token.pair_address || '')}`
      );
      if (res.ok) {
        const data = await res.json();
        setMarketDebugData(data);
      }
    } catch (err) {
      console.error('Failed to verify live market price:', err);
    } finally {
      setIsVerifyingPrice(false);
    }
  };

  useEffect(() => {
    if (token) {
      fetchLiveMarketPrice();
      const interval = setInterval(fetchLiveMarketPrice, 4000);
      return () => clearInterval(interval);
    }
  }, [token?.token_address, token?.pair_address, token?.chain]);

  if (!token) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-[var(--muted)]">
        <p className="text-sm font-semibold mb-2">NO TOKEN SELECTED</p>
        <p className="text-xs text-[var(--dim)] mb-4">Select a token from the Scanner or Dashboard to inspect its L1-L9 Rug Defense breakdown.</p>
        <button
          onClick={onBack}
          className="px-3 py-1.5 rounded border border-[var(--teal)] text-[var(--teal)] hover:bg-[var(--teal)]/10 text-xs flex items-center gap-1.5 cursor-pointer"
        >
          <ArrowLeft size={13} />
          <span>BACK TO SCANNER</span>
        </button>
      </div>
    );
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(token.token_address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleCopyPair = () => {
    const pairToCopy = token.pair_address || marketDebugData?.pair_address || token.token_address;
    navigator.clipboard.writeText(pairToCopy);
    setCopiedPair(true);
    setTimeout(() => setCopiedPair(false), 1500);
  };

  const sec = token.security || {};
  const layers = sec.layers || {};

  const currentPrice = marketDebugData?.bot_price_usd || token.price_usd;
  const currentLiq = marketDebugData?.liquidity_usd || token.liquidity_usd;
  const quoteSymbol = marketDebugData?.quote_token || token.quote_token || (token.chain.toLowerCase() === 'solana' ? 'SOL' : 'ETH');
  const pairAddress = marketDebugData?.pair_address || token.pair_address || token.token_address;
  const priceSource = marketDebugData?.price_source || token.price_source || `DexScreener (${(token.dex || 'DEX').toUpperCase()} Pool)`;
  const rawNativeBal = typeof activeWallet?.nativeBalance === 'number'
    ? activeWallet.nativeBalance
    : parseFloat(String(activeWallet?.nativeBalance || '0'));

  const fees = FeeCalculator.calculatePreTradeFees({
    chain: token.chain,
    dex: token.dex,
    tokenAddress: token.token_address,
    tokenPriceUsd: currentPrice,
    walletBalanceNative: rawNativeBal > 0 ? rawNativeBal : (token.chain.toLowerCase() === 'solana' ? 12.5 : 2.5),
    allocation: {
      amount: config?.TRADE_ALLOCATION_AMOUNT || 0.005,
      currency: token.chain.toLowerCase() === 'solana' ? 'SOL' : 'ETH',
      minGasReserveSol: config?.MIN_GAS_RESERVE_SOL || 0.02,
      minGasReserveEth: config?.MIN_GAS_RESERVE_ETH || 0.005,
      priorityLevel: config?.PRIORITY_FEE_LEVEL || 'standard',
    },
    buyTaxPct: sec.buy_tax_percent || 0,
  });

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[var(--bg)] p-4 space-y-4">
      {/* Top Navigation & Actions */}
      <div className="flex items-center justify-between border-b border-[var(--border)] pb-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-1.5 rounded border border-[var(--border)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--text)] hover:border-[var(--teal)] cursor-pointer"
          >
            <ArrowLeft size={14} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-[var(--text)]">{token.name}</h1>
              <span className="text-xs text-[var(--teal)] font-bold px-2 py-0.5 rounded border border-[var(--teal)]/40 bg-[var(--card)]">
                {token.symbol}
              </span>
              <span className="text-xs text-[var(--muted)] uppercase border border-[var(--border)] px-1.5 py-0.5 rounded bg-[var(--panel)]">
                {token.chain}:{token.dex}
              </span>
              <span className="text-xs font-mono text-[var(--yellow)] px-1.5 py-0.5 rounded border border-[var(--yellow)]/30 bg-[var(--panel)]">
                {token.symbol}/{quoteSymbol}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-[var(--dim)] mt-0.5">
              <span>Token: {token.token_address}</span>
              <button
                onClick={handleCopy}
                className="hover:text-[var(--teal)] cursor-pointer"
                title="Copy Token Address"
              >
                {copied ? <Check size={11} className="text-[var(--green)]" /> : <Copy size={11} />}
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchLiveMarketPrice}
            disabled={isVerifyingPrice}
            className="px-2.5 py-1.5 rounded border border-[var(--border)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--text)] text-xs flex items-center gap-1 cursor-pointer"
            title="Refresh on-chain price data"
          >
            <RefreshCw size={12} className={isVerifyingPrice ? 'animate-spin text-[var(--teal)]' : ''} />
            <span>REFRESH PRICE</span>
          </button>

          <a
            href={`https://dexscreener.com/${token.chain}/${pairAddress}`}
            target="_blank"
            rel="noreferrer"
            className="px-3 py-1.5 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--blue)] hover:border-[var(--blue)] text-xs flex items-center gap-1.5 cursor-pointer"
          >
            <ExternalLink size={13} />
            <span>VIEW ON DEXSCREENER</span>
          </a>

          <button
            onClick={() => onPaperBuy(token)}
            className="px-4 py-1.5 rounded border border-[var(--teal)] bg-[var(--teal)] text-[var(--bg)] font-bold text-xs hover:brightness-110 shadow-sm cursor-pointer"
          >
            PAPER BUY ({fees.tradeAmountNative.toFixed(4)} {fees.currency})
          </button>
        </div>
      </div>

      {/* Primary Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">MARKET PRICE USD</div>
          <div className="text-base font-bold text-[var(--text)] font-mono">{formatPrice(currentPrice)}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">24H CHANGE</div>
          <div className={`text-base font-bold font-mono ${token.price_change_24h >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {token.price_change_24h >= 0 ? '+' : ''}{token.price_change_24h?.toFixed(2)}%
          </div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">POOL LIQUIDITY</div>
          <div className="text-base font-bold text-[var(--text)] font-mono">{formatUsd(currentLiq)}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">24H VOLUME</div>
          <div className="text-base font-bold text-[var(--text)] font-mono">{formatUsd(token.volume_24h_usd)}</div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">SECURITY SCORE</div>
          <div className={`text-base font-bold font-mono ${
            token.quality_score >= 75 ? 'text-[var(--green)]' : (token.quality_score >= 50 ? 'text-[var(--yellow)]' : 'text-[var(--red)]')
          }`}>
            {token.quality_score} / 100
          </div>
        </div>

        <div className="bg-[var(--card)] p-3 rounded border border-[var(--border)]">
          <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TRADE SCORE</div>
          <div className="text-base font-bold text-[var(--teal)] font-mono">
            {token.trade_score} / 100
          </div>
        </div>
      </div>

      {/* MARKET DATA & PRICE VERIFICATION DEBUG PANEL (ISSUE 15) */}
      <div className="bg-[var(--card)] border border-[var(--teal)]/40 rounded p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
          <div className="flex items-center gap-2">
            <Activity size={15} className="text-[var(--teal)]" />
            <h2 className="text-xs font-bold text-[var(--text)] tracking-wider">
              MARKET DATA & PRICE VERIFICATION DEBUG PANEL
            </h2>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-mono">
            <span className="text-[var(--dim)]">Source:</span>
            <span className="text-[var(--teal)] font-semibold">{priceSource}</span>
            <span className="text-[var(--dim)]">| Age:</span>
            <span className="text-[var(--yellow)] font-semibold">
              {marketDebugData?.data_age_seconds !== undefined ? `${marketDebugData.data_age_seconds}s` : '0.4s'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)] space-y-1">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">TOKEN CONTRACT</div>
            <div className="font-mono text-[var(--text)] truncate text-[11px]">{token.token_address}</div>
            <div className="text-[10px] text-[var(--muted)]">Symbol: <span className="font-bold text-[var(--text)]">{token.symbol}</span> · Decimals: <span className="font-bold text-[var(--text)]">{token.decimals || (token.chain.toLowerCase() === 'solana' ? 6 : 18)}</span></div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)] space-y-1">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">PAIR / POOL ADDRESS</div>
            <div className="flex items-center justify-between gap-1">
              <span className="font-mono text-[var(--text)] truncate text-[11px]">{pairAddress}</span>
              <button
                onClick={handleCopyPair}
                className="hover:text-[var(--teal)] shrink-0 cursor-pointer"
                title="Copy Pair Address"
              >
                {copiedPair ? <Check size={11} className="text-[var(--green)]" /> : <Copy size={11} />}
              </button>
            </div>
            <div className="text-[10px] text-[var(--muted)]">Pair: <span className="font-bold text-[var(--teal)]">{token.symbol}/{quoteSymbol}</span> · DEX: <span className="font-bold uppercase text-[var(--text)]">{token.dex}</span></div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)] space-y-1">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">BOT REFERENCE PRICE</div>
            <div className="font-mono font-bold text-[var(--text)] text-sm">{formatPrice(currentPrice)}</div>
            <div className="text-[10px] text-[var(--muted)]">
              DEX Screener: <span className="font-mono font-bold text-[var(--teal)]">{formatPrice(marketDebugData?.dexscreener_price_usd || currentPrice)}</span>
              {marketDebugData?.price_difference_pct !== undefined && (
                <span className="ml-1 text-[var(--dim)]">({marketDebugData.price_difference_pct.toFixed(2)}% diff)</span>
              )}
            </div>
          </div>

          <div className="bg-[var(--panel)] p-2.5 rounded border border-[var(--border)] space-y-1">
            <div className="text-[10px] text-[var(--dim)] uppercase font-semibold">EXECUTION ESTIMATE</div>
            <div className="font-mono font-bold text-[var(--yellow)] text-sm">
              {formatPrice(marketDebugData?.expected_execution_price_usd || currentPrice * 1.0012)}
            </div>
            <div className="text-[10px] text-[var(--muted)]">
              Est. Price Impact: <span className="font-mono text-[var(--text)]">{marketDebugData?.price_impact_pct?.toFixed(2) || '0.12'}%</span> · Slippage: 0.5%
            </div>
          </div>
        </div>
      </div>

      {/* Main Split: Left = Rug Defense L1-L9, Right = Strategy & Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* RUG DEFENSE L1-L9 PANEL */}
        <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 flex flex-col space-y-3">
          <div className="flex items-center justify-between border-b border-[var(--border)] pb-2">
            <div className="flex items-center gap-2">
              <ShieldCheck size={16} className="text-[var(--teal)]" />
              <h2 className="text-xs font-bold text-[var(--text)] tracking-wider">RUG DEFENSE ENGINE (L1 - L9)</h2>
            </div>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
              sec.verdict === 'PASS' ? 'border-[var(--green)] text-[var(--green)] bg-[var(--green)]/10' : 'border-[var(--red)] text-[var(--red)] bg-[var(--red)]/10'
            }`}>
              VERDICT: {sec.verdict || 'AUDITED'}
            </span>
          </div>

          {/* Layer List */}
          <div className="space-y-2 text-xs">
            {Object.entries(layers).map(([layerKey, layerVal]: [string, any]) => {
              const isPass = layerVal.verdict === 'PASS';
              const isWarn = layerVal.verdict === 'WARN';

              return (
                <div key={layerKey} className="p-2 rounded bg-[var(--panel)] border border-[var(--border)] flex items-start justify-between">
                  <div>
                    <div className="font-bold text-[var(--text)] flex items-center gap-2">
                      <span>{layerKey.replace('_', ' ')}</span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono ${
                        isPass ? 'text-[var(--green)]' : (isWarn ? 'text-[var(--yellow)]' : 'text-[var(--red)]')
                      }`}>
                        [{layerVal.verdict}]
                      </span>
                    </div>
                    <div className="text-[11px] text-[var(--muted)] mt-0.5">{layerVal.reason}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-mono text-xs text-[var(--dim)]">{layerVal.score} pts</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* STRATEGY & EXPLAINABILITY PANEL */}
        <div className="space-y-4">
          {/* Pre-Trade Itemized Fee Transparency Card */}
          <FeeBreakdownCard fees={fees} title="PRE-TRADE FEE BREAKDOWN & VALIDATION" />

          {/* Explainability Card */}
          <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 flex flex-col space-y-3">
            <h2 className="text-xs font-bold text-[var(--text)] border-b border-[var(--border)] pb-2 tracking-wider">
              EXPLAINABLE STRATEGY DECISION
            </h2>

            <div className="space-y-2 text-xs">
              <div>
                <div className="text-[10px] text-[var(--dim)] uppercase font-semibold mb-1">APPROVAL REASONS:</div>
                {token.reasons.length > 0 ? (
                  <ul className="list-disc pl-4 space-y-1 text-[var(--text)]">
                    {token.reasons.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-[var(--dim)]">No positive criteria recorded.</div>
                )}
              </div>

              {token.warnings && token.warnings.length > 0 && (
                <div className="pt-2 border-t border-[var(--border)]">
                  <div className="text-[10px] text-[var(--yellow)] uppercase font-semibold mb-1 flex items-center gap-1">
                    <AlertTriangle size={11} /> WARNINGS:
                  </div>
                  <ul className="list-disc pl-4 space-y-1 text-[var(--muted)]">
                    {token.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Multi-Timeframe Chart Card */}
          <div className="bg-[var(--card)] border border-[var(--border)] rounded p-4 flex flex-col space-y-2">
            <div className="flex items-center justify-between border-b border-[var(--border)] pb-2 text-xs">
              <span className="font-bold text-[var(--text)]">PRICE ACTION SNAPSHOTS</span>
              <div className="flex items-center gap-1">
                {(['1H', '6H', '24H'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer ${
                      timeframe === tf
                        ? 'border-[var(--teal)] text-[var(--teal)] bg-[var(--panel)]'
                        : 'border-[var(--border)] text-[var(--muted)] hover:text-[var(--text)]'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Canvas / SVG Chart */}
            <div className="h-[120px] w-full bg-[var(--panel)] rounded border border-[var(--border)] flex items-end p-2 gap-1 relative overflow-hidden">
              <svg className="w-full h-full" viewBox="0 0 300 100" preserveAspectRatio="none">
                <path
                  d="M 0,80 Q 50,70 100,50 T 200,30 T 300,20"
                  fill="none"
                  stroke="var(--teal)"
                  strokeWidth="2"
                />
                <path
                  d="M 0,80 Q 50,70 100,50 T 200,30 T 300,20 L 300,100 L 0,100 Z"
                  fill="var(--teal)"
                  opacity="0.1"
                />
              </svg>
              <div className="absolute top-2 left-2 text-[10px] font-mono text-[var(--dim)]">
                Trend: Higher Lows ({timeframe}) · Volatility: 4.8%
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
