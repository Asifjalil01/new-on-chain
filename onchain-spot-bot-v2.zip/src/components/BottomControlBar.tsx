import React from 'react';
import { Play, Square, Pause, AlertTriangle, RefreshCw, Eye, Settings, PlayCircle, Lock } from 'lucide-react';
import { useBot } from '../context/BotContext';

export const BottomControlBar: React.FC = () => {
  const {
    botStatus,
    isBotStopped,
    handleControlAction,
    navigateToTab,
    config,
    activeWallet,
  } = useBot();

  const isRunning = botStatus.is_running && !isBotStopped;
  const isScannerActive = botStatus.is_scanner_active;
  const isBuyingPaused = botStatus.is_buying_paused;
  const isEmergencyPaused = botStatus.is_emergency_paused;
  const isLive = config.EXECUTION_MODE === 'live';

  return (
    <footer className="h-[46px] bg-[var(--panel)] border-t border-[var(--border)] px-3 flex items-center justify-between text-xs select-none shrink-0 font-mono z-20">
      <div className="flex items-center gap-2 overflow-x-auto py-1">
        {/* SETTINGS */}
        <button
          onClick={() => navigateToTab('settings')}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--text)] hover:border-[var(--teal)] hover:text-[var(--teal)] transition-colors cursor-pointer text-xs"
        >
          <Settings size={13} />
          <span>SETTINGS</span>
        </button>

        {/* SCANNER CONTROLS */}
        {isScannerActive && !isBotStopped ? (
          <button
            onClick={() => handleControlAction('stop_scanner')}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--orange)] hover:bg-[var(--card-hover)] transition-colors cursor-pointer text-xs"
            title="Stop scanner discovery only"
          >
            <Square size={12} />
            <span>STOP SCANNER</span>
          </button>
        ) : (
          <button
            onClick={() => handleControlAction('start_scanner')}
            disabled={isBotStopped}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] hover:bg-[var(--teal)]/10 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-xs"
            title={isBotStopped ? 'Start bot first to resume scanner' : 'Start universe discovery scanner'}
          >
            <Play size={12} />
            <span>START SCANNER</span>
          </button>
        )}

        {/* SCAN MARKET (VIEW ONLY) */}
        <button
          onClick={() => handleControlAction('scan_once')}
          disabled={isBotStopped}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--text)] hover:border-[var(--blue)] hover:text-[var(--blue)] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-xs"
        >
          <Eye size={13} />
          <span>SCAN MARKET (VIEW ONLY)</span>
        </button>

        {/* PAPER TEST (ONE CYCLE) */}
        <button
          onClick={() => handleControlAction('paper_test_cycle')}
          disabled={isBotStopped || isLive}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--yellow)] hover:border-[var(--yellow)] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-xs"
          title={isLive ? 'Disabled in Live mode' : 'Execute one simulated paper test cycle'}
        >
          <PlayCircle size={13} />
          <span>PAPER TEST</span>
        </button>

        {/* PAUSE / RESUME BUYING */}
        {isBuyingPaused ? (
          <button
            onClick={() => handleControlAction('resume_buying')}
            disabled={isBotStopped}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--green)] bg-[var(--card)] text-[var(--green)] hover:bg-[var(--green)]/10 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-xs"
          >
            <Play size={12} />
            <span>RESUME BUYING</span>
          </button>
        ) : (
          <button
            onClick={() => handleControlAction('pause_buying')}
            disabled={isBotStopped}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-[var(--yellow)] bg-[var(--card)] text-[var(--yellow)] hover:bg-[var(--yellow)]/10 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed text-xs"
            title="Scanning continues, but new buy orders are blocked"
          >
            <Pause size={12} />
            <span>PAUSE BUYING</span>
          </button>
        )}

        {/* EMERGENCY PAUSE */}
        <button
          onClick={() => handleControlAction('emergency_pause')}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-colors cursor-pointer text-xs ${
            isEmergencyPaused
              ? 'border-[var(--red)] bg-[var(--red)] text-white font-bold'
              : 'border-[var(--red)] text-[var(--red)] hover:bg-[var(--red)]/20'
          }`}
          title="Fail-closed kill switch: immediately blocks all orders"
        >
          <AlertTriangle size={13} />
          <span>EMERGENCY PAUSE</span>
        </button>

        {/* REFRESH */}
        <button
          onClick={() => handleControlAction('refresh')}
          className="flex items-center gap-1.5 px-2 py-1 rounded border border-[var(--border-bright)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--text)] transition-colors cursor-pointer text-xs"
          title="Force refresh token feeds"
        >
          <RefreshCw size={13} />
        </button>
      </div>

      {/* START BOT / STOP BOT (Primary Action) */}
      <div className="shrink-0 pl-2">
        {isRunning ? (
          <button
            onClick={() => handleControlAction('stop_bot')}
            className="flex items-center gap-2 px-4 py-1.5 rounded font-bold border border-[var(--red)] bg-[var(--red)]/20 text-[var(--red)] hover:bg-[var(--red)] hover:text-white transition-all cursor-pointer text-xs shadow-sm"
            title="Halts engine, scanner, price feeds, timers and blocks all new orders"
          >
            <Square size={13} />
            <span>STOP BOT</span>
          </button>
        ) : (
          <button
            onClick={() => handleControlAction('start_bot')}
            className="flex items-center gap-2 px-4 py-1.5 rounded font-bold border border-[var(--teal)] bg-[var(--teal)] text-[var(--bg)] hover:brightness-110 shadow-md transition-all cursor-pointer text-xs"
            title="Start engine with single-instance lock"
          >
            <Play size={13} />
            <span>START BOT</span>
          </button>
        )}
      </div>
    </footer>
  );
};
