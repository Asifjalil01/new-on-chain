import React, { useState } from 'react';
import { Search, ChevronLeft, ChevronRight, ExternalLink, ShieldCheck, AlertTriangle, RefreshCw, Flame, Sparkles, Filter, ArrowUpDown } from 'lucide-react';
import { formatPrice, formatUsd, formatTimeAgo } from '../utils/formatters';

export interface UniverseToken {
  chain: string;
  token_address: string;
  pair_address: string;
  symbol: string;
  name: string;
  dex: string;
  quote_token?: string;
  price_usd: number;
  price_native?: number;
  price_source?: string;
  price_updated_at?: number;
  liquidity_usd: number;
  volume_24h_usd: number;
  market_cap_usd?: number;
  price_change_1h: number;
  price_change_24h: number;
  txns_24h_buys: number;
  txns_24h_sells: number;
  pair_created_at_ms: number;
  tier: number;
  state: string;
  reject_reason?: string;
  quality_score: number;
  trade_score: number;
  momentum_score?: number;
  risk_level: string;
  source?: string;
  first_seen_at?: number;
  last_scanned_at?: number;
}

export interface ScannerCategoryCounts {
  ALL: number;
  BUY: number;
  WATCH: number;
  WAIT: number;
  REJECT: number;
  'RUG RISK': number;
  HONEYPOT: number;
  POSITION: number;
  COOLDOWN: number;
}

export interface DiscoveryStats {
  candidates_fetched_this_cycle: number;
  passed_prefilter_this_cycle: number;
  passed_deep_checks_this_cycle: number;
  rejected_this_cycle: number;
  rejected_reasons_breakdown: Record<string, number>;
  new_tokens_discovered_this_cycle: number;
  total_seen_tokens: number;
  new_per_hour: number;
  repeated_vs_new_ratio: string;
  last_scan_duration_ms: number;
  source_breakdown: Record<string, number>;
}

interface ScannerViewProps {
  tokens: UniverseToken[];
  totalCount: number;
  currentPage: number;
  pageSize: number;
  counts: ScannerCategoryCounts;
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  selectedChain: string;
  onSelectChain: (chain: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onPageChange: (newPage: number) => void;
  onInspectToken: (chain: string, address: string) => void;
  discoveryStats?: DiscoveryStats | null;
  onResetSeenCache?: () => void;
  sortBy?: string;
  onSortChange?: (field: string) => void;
}

export const ScannerView: React.FC<ScannerViewProps> = ({
  tokens,
  totalCount,
  currentPage,
  pageSize,
  counts,
  selectedCategory,
  onSelectCategory,
  selectedChain,
  onSelectChain,
  searchQuery,
  onSearchChange,
  onPageChange,
  onInspectToken,
  discoveryStats,
  onResetSeenCache,
  sortBy = 'score',
  onSortChange,
}) => {
  const [isResetting, setIsResetting] = useState(false);

  const categories = [
    { key: 'ALL', label: 'ALL' },
    { key: 'BUY', label: 'BUY' },
    { key: 'WATCH', label: 'WATCH' },
    { key: 'WAIT', label: 'WAIT' },
    { key: 'REJECT', label: 'REJECT' },
    { key: 'RUG RISK', label: 'RUG RISK' },
    { key: 'HONEYPOT', label: 'HONEYPOT' },
    { key: 'POSITION', label: 'POSITION' },
    { key: 'COOLDOWN', label: 'COOLDOWN' },
  ];

  const chains = ['all', 'solana', 'base', 'ethereum', 'bsc', 'arbitrum', 'polygon', 'avalanche', 'optimism'];
  const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));

  const handleReset = async () => {
    if (!onResetSeenCache) return;
    setIsResetting(true);
    try {
      await onResetSeenCache();
    } finally {
      setTimeout(() => setIsResetting(false), 800);
    }
  };

  const getSourceBadge = (source?: string) => {
    if (!source) return null;
    if (source.includes('boost')) {
      return (
        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[var(--yellow)]/10 text-[var(--yellow)] border border-[var(--yellow)]/30 flex items-center gap-1">
          <Flame size={9} />
          <span>BOOST</span>
        </span>
      );
    }
    if (source.includes('trending')) {
      return (
        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[var(--teal)]/10 text-[var(--teal)] border border-[var(--teal)]/30 flex items-center gap-1">
          <Sparkles size={9} />
          <span>TRENDING</span>
        </span>
      );
    }
    if (source.includes('new')) {
      return (
        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[var(--green)]/10 text-[var(--green)] border border-[var(--green)]/30">
          NEW
        </span>
      );
    }
    if (source.includes('takeover')) {
      return (
        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[var(--purple,#a855f7)]/10 text-[var(--purple,#a855f7)] border border-[var(--purple,#a855f7)]/30">
          CTO
        </span>
      );
    }
    return (
      <span className="px-1.5 py-0.5 rounded text-[9px] font-mono text-[var(--dim)] bg-[var(--panel)] border border-[var(--border)]">
        DEX
      </span>
    );
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* 1. DISCOVERY INTAKE FUNNEL BANNER */}
      {discoveryStats && (
        <div className="bg-[var(--panel)] border-b border-[var(--border)] px-4 py-2 flex flex-wrap items-center justify-between text-xs gap-3">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">CANDIDATES EVALUATED:</span>
              <span className="font-bold font-mono text-[var(--text)]">{discoveryStats.candidates_fetched_this_cycle}</span>
            </div>

            <div className="h-3 w-[1px] bg-[var(--border)] hidden sm:block"></div>

            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">PRE-FILTER PASSED:</span>
              <span className="font-bold font-mono text-[var(--green)]">{discoveryStats.passed_prefilter_this_cycle}</span>
            </div>

            <div className="h-3 w-[1px] bg-[var(--border)] hidden sm:block"></div>

            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">DEEP AUDITED:</span>
              <span className="font-bold font-mono text-[var(--teal)]">{discoveryStats.passed_deep_checks_this_cycle}</span>
            </div>

            <div className="h-3 w-[1px] bg-[var(--border)] hidden sm:block"></div>

            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">REJECTED:</span>
              <span className="font-bold font-mono text-[var(--red)]">{discoveryStats.rejected_this_cycle}</span>
            </div>

            <div className="h-3 w-[1px] bg-[var(--border)] hidden sm:block"></div>

            <div className="flex items-center gap-1.5">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">NEW DISCOVERED:</span>
              <span className="font-bold font-mono text-[var(--yellow)]">+{discoveryStats.new_tokens_discovered_this_cycle}</span>
            </div>

            <div className="h-3 w-[1px] bg-[var(--border)] hidden md:block"></div>

            <div className="flex items-center gap-1.5 hidden md:flex">
              <span className="text-[10px] uppercase font-bold text-[var(--dim)]">SEEN REGISTRY:</span>
              <span className="font-mono text-[var(--muted)]">{discoveryStats.total_seen_tokens} tokens</span>
            </div>
          </div>

          {onResetSeenCache && (
            <button
              onClick={handleReset}
              disabled={isResetting}
              className="px-2.5 py-1 rounded text-[10px] font-bold border border-[var(--border-bright)] bg-[var(--card)] hover:border-[var(--teal)] text-[var(--text)] hover:text-[var(--teal)] flex items-center gap-1.5 cursor-pointer transition-colors shrink-0"
              title="Clear Seen-Token cache and universe to trigger a fresh discovery sweep"
            >
              <RefreshCw size={11} className={isResetting ? 'animate-spin text-[var(--teal)]' : ''} />
              <span>{isResetting ? 'RESETTING...' : 'RESET SEEN CACHE'}</span>
            </button>
          )}
        </div>
      )}

      {/* 2. CATEGORY PILLS BAR */}
      <div className="h-[44px] bg-[var(--panel)] border-b border-[var(--border)] px-4 flex items-center gap-2 overflow-x-auto select-none">
        {categories.map((cat) => {
          const count = counts[cat.key as keyof ScannerCategoryCounts] || 0;
          const isSelected = selectedCategory === cat.key;
          let countColor = 'text-[var(--muted)]';
          if (cat.key === 'BUY') countColor = 'text-[var(--teal)]';
          if (cat.key === 'REJECT') countColor = 'text-[var(--red)]';
          if (cat.key === 'RUG RISK' || cat.key === 'HONEYPOT') countColor = 'text-[var(--red)]';
          if (cat.key === 'POSITION') countColor = 'text-[var(--green)]';

          return (
            <button
              key={cat.key}
              onClick={() => onSelectCategory(cat.key)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold border transition-colors cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'border-[var(--teal)] bg-[var(--card)] text-[var(--teal)] shadow-sm'
                  : 'border-[var(--border)] bg-[var(--panel)] text-[var(--muted)] hover:text-[var(--text)] hover:border-[var(--border-bright)]'
              }`}
            >
              <span>{cat.label}</span>
              <span className={`px-1.5 py-0.2 rounded text-[10px] bg-[var(--bg)] ${countColor}`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* 3. FILTER, SEARCH AND PAGINATION BAR */}
      <div className="h-[42px] bg-[var(--card)] border-b border-[var(--border)] px-4 flex items-center justify-between text-xs gap-4 select-none">
        <div className="flex items-center gap-3 flex-1 max-w-xl">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--dim)]" />
            <input
              type="text"
              placeholder="Search by symbol, name, or address..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-[var(--panel)] border border-[var(--border-bright)] rounded pl-8 pr-3 py-1 text-xs text-[var(--text)] focus:outline-none focus:border-[var(--teal)]"
            />
          </div>

          {/* Chain Dropdown */}
          <select
            value={selectedChain}
            onChange={(e) => onSelectChain(e.target.value)}
            className="bg-[var(--panel)] border border-[var(--border-bright)] text-[var(--text)] px-2 py-1 rounded text-xs focus:outline-none focus:border-[var(--teal)] cursor-pointer"
          >
            {chains.map((c) => (
              <option key={c} value={c}>
                {c === 'all' ? 'ALL CHAINS' : c.toUpperCase()}
              </option>
            ))}
          </select>

          {/* Sort By Dropdown */}
          {onSortChange && (
            <div className="flex items-center gap-1.5 text-xs text-[var(--dim)] shrink-0">
              <ArrowUpDown size={12} />
              <select
                value={sortBy}
                onChange={(e) => onSortChange(e.target.value)}
                className="bg-[var(--panel)] border border-[var(--border-bright)] text-[var(--text)] px-2 py-1 rounded text-xs focus:outline-none focus:border-[var(--teal)] cursor-pointer"
              >
                <option value="score">SORT: STRATEGY SCORE</option>
                <option value="volume">SORT: 24H VOLUME</option>
                <option value="liquidity">SORT: LIQUIDITY</option>
                <option value="change24h">SORT: 24H % GAIN</option>
                <option value="age">SORT: NEWEST PAIRS</option>
                <option value="first_seen">SORT: FIRST SEEN</option>
              </select>
            </div>
          )}
        </div>

        {/* Pagination Indicator */}
        <div className="flex items-center gap-2 text-xs text-[var(--muted)]">
          <span>
            Page <span className="font-bold text-[var(--text)]">{currentPage}</span> of{' '}
            <span className="font-bold text-[var(--text)]">{totalPages}</span> ({totalCount} total)
          </span>

          <div className="flex items-center gap-1">
            <button
              onClick={() => onPageChange(Math.max(1, currentPage - 1))}
              disabled={currentPage <= 1}
              className="p-1 rounded border border-[var(--border-bright)] bg-[var(--panel)] disabled:opacity-40 hover:text-[var(--teal)] cursor-pointer"
            >
              <ChevronLeft size={13} />
            </button>
            <button
              onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage >= totalPages}
              className="p-1 rounded border border-[var(--border-bright)] bg-[var(--panel)] disabled:opacity-40 hover:text-[var(--teal)] cursor-pointer"
            >
              <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* 4. UNIVERSE TABLE */}
      <div className="flex-1 overflow-x-auto overflow-y-auto">
        <table className="w-full border-collapse text-left text-xs font-mono">
          <thead className="sticky top-0 bg-[var(--panel)] border-b border-[var(--border)] text-[10px] text-[var(--dim)] uppercase z-10 select-none">
            <tr>
              <th className="py-2.5 px-3">#</th>
              <th className="py-2.5 px-3">TOKEN</th>
              <th className="py-2.5 px-3">SOURCE</th>
              <th className="py-2.5 px-3">CHAIN</th>
              <th className="py-2.5 px-3">DEX</th>
              <th className="py-2.5 px-3 text-right">PRICE</th>
              <th className="py-2.5 px-3 text-right">24H %</th>
              <th className="py-2.5 px-3 text-right">VOLUME</th>
              <th className="py-2.5 px-3 text-right">LIQUIDITY</th>
              <th className="py-2.5 px-3 text-right">AGE</th>
              <th className="py-2.5 px-3 text-center">TXNS (B/S)</th>
              <th className="py-2.5 px-3 text-center">SECURITY</th>
              <th className="py-2.5 px-3 text-center">TRADE</th>
              <th className="py-2.5 px-3 text-center">STATUS</th>
              <th className="py-2.5 px-3 text-center">ACTION</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[var(--border)] bg-[var(--card)]">
            {tokens.length === 0 ? (
              <tr>
                <td colSpan={15} className="py-16 text-center text-[var(--muted)]">
                  No tokens matched the selected filters.
                </td>
              </tr>
            ) : (
              tokens.map((t, idx) => {
                const rank = (currentPage - 1) * pageSize + idx + 1;
                const isProfit = t.price_change_24h >= 0;

                let statusBadge = 'border-[var(--dim)] text-[var(--dim)]';
                if (t.state === 'BUY_APPROVED') statusBadge = 'border-[var(--teal)] text-[var(--teal)] bg-[var(--teal)]/10 font-bold';
                else if (t.state === 'WATCHLIST') statusBadge = 'border-[var(--blue)] text-[var(--blue)] bg-[var(--blue)]/10 font-semibold';
                else if (t.state === 'REJECTED') statusBadge = 'border-[var(--red)]/60 text-[var(--red)] bg-[var(--red)]/5';
                else if (t.state === 'RUG_RISK' || t.state === 'HONEYPOT') statusBadge = 'border-[var(--red)] text-[var(--red)] bg-[var(--red)]/10 font-bold';
                else if (t.state === 'POSITION_OPEN') statusBadge = 'border-[var(--green)] text-[var(--green)] bg-[var(--green)]/10 font-bold';

                return (
                  <tr
                    key={`${t.chain}_${t.token_address}`}
                    className="hover:bg-[var(--card-hover)] transition-colors cursor-pointer"
                    onClick={() => onInspectToken(t.chain, t.token_address)}
                  >
                    <td className="py-2 px-3 text-[var(--dim)]">{rank}</td>
                    <td className="py-2 px-3">
                      <div className="font-bold text-[var(--text)] flex items-center gap-1.5">
                        <span>{t.symbol}</span>
                        <span className="text-[9px] text-[var(--teal)] font-mono font-normal">
                          /{t.quote_token || (t.chain.toLowerCase() === 'solana' ? 'SOL' : 'ETH')}
                        </span>
                      </div>
                      <div className="text-[10px] text-[var(--dim)] truncate max-w-[130px]">{t.name}</div>
                      {t.reject_reason && (
                        <div className="text-[9px] text-[var(--red)] truncate max-w-[150px] font-mono mt-0.5" title={t.reject_reason}>
                          {t.reject_reason}
                        </div>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      {getSourceBadge(t.source)}
                    </td>
                    <td className="py-2 px-3 text-[var(--muted)] uppercase">{t.chain}</td>
                    <td className="py-2 px-3 text-[var(--muted)] uppercase">{t.dex}</td>
                    <td className="py-2 px-3 text-right font-bold text-[var(--text)]">{formatPrice(t.price_usd)}</td>
                    <td className={`py-2 px-3 text-right font-bold ${isProfit ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
                      {isProfit ? '+' : ''}{t.price_change_24h?.toFixed(1)}%
                    </td>
                    <td className="py-2 px-3 text-right text-[var(--muted)]">{formatUsd(t.volume_24h_usd)}</td>
                    <td className="py-2 px-3 text-right text-[var(--muted)]">{formatUsd(t.liquidity_usd)}</td>
                    <td className="py-2 px-3 text-right text-[var(--dim)]">{formatTimeAgo(t.pair_created_at_ms)}</td>
                    <td className="py-2 px-3 text-center text-[var(--dim)]">
                      <span className="text-[var(--green)]">{t.txns_24h_buys || 0}</span> /{' '}
                      <span className="text-[var(--red)]">{t.txns_24h_sells || 0}</span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                        t.quality_score >= 75 ? 'text-[var(--green)]' : (t.quality_score >= 50 ? 'text-[var(--yellow)]' : 'text-[var(--red)]')
                      }`}>
                        {t.quality_score}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold ${
                        t.trade_score >= 70 ? 'text-[var(--teal)]' : 'text-[var(--muted)]'
                      }`}>
                        {t.trade_score}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded border text-[10px] uppercase ${statusBadge}`}>
                        {t.state}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onInspectToken(t.chain, t.token_address);
                        }}
                        className="px-2 py-0.5 rounded border border-[var(--border-bright)] bg-[var(--panel)] text-[var(--teal)] hover:bg-[var(--card)] text-[10px] flex items-center gap-1 mx-auto cursor-pointer"
                      >
                        <ExternalLink size={10} />
                        <span>INSPECT</span>
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
