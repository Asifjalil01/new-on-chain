import React from 'react';
import { ShieldCheck, AlertCircle, Info, DollarSign } from 'lucide-react';
import { FeeBreakdown } from '../fees/FeeCalculator';
import { formatUsd } from '../utils/formatters';

interface FeeBreakdownCardProps {
  fees: FeeBreakdown;
  title?: string;
  showAffordabilityNotice?: boolean;
}

export const FeeBreakdownCard: React.FC<FeeBreakdownCardProps> = ({
  fees,
  title = 'TRANSACTION FEE & COST TRANSPARENCY',
  showAffordabilityNotice = true,
}) => {
  return (
    <div className="bg-[var(--panel)] border border-[var(--border)] rounded p-3 text-xs font-mono flex flex-col gap-2">
      <div className="flex items-center justify-between border-b border-[var(--border)] pb-1.5">
        <span className="font-bold text-[var(--text)] tracking-wider flex items-center gap-1.5">
          <DollarSign size={13} className="text-[var(--teal)]" />
          <span>{title}</span>
        </span>
        <span className="text-[10px] text-[var(--dim)] uppercase">
          {fees.isEstimate ? '[ESTIMATED QUOTE]' : '[CONFIRMED ON-CHAIN]'}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[11px]">
        <div className="flex justify-between">
          <span className="text-[var(--dim)]">Trade Allocation:</span>
          <span className="font-bold text-[var(--text)]">{formatUsd(fees.tradeAmountUsd)}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-[var(--dim)]">DEX Execution Fee:</span>
          <span className="text-[var(--muted)]">{formatUsd(fees.dexFeeUsd)}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-[var(--dim)]">Network Gas Base Fee:</span>
          <span className="text-[var(--muted)]">{formatUsd(fees.networkGasFeeUsd)}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-[var(--dim)]">Priority / Compute Tip:</span>
          <span className="text-[var(--muted)]">{formatUsd(fees.priorityFeeUsd)}</span>
        </div>

        {fees.ataRentFeeUsd > 0 && (
          <div className="flex justify-between">
            <span className="text-[var(--dim)]">ATA Rent Reserve (Solana):</span>
            <span className="text-[var(--muted)]">{formatUsd(fees.ataRentFeeUsd)}</span>
          </div>
        )}

        <div className="flex justify-between">
          <span className="text-[var(--dim)]">DEX Screener Routing Fee:</span>
          <span className="text-[var(--green)] font-semibold">$0.00 (Free Data API)</span>
        </div>

        {fees.tokenTaxUsd > 0 && (
          <div className="flex justify-between">
            <span className="text-[var(--dim)]">Token Contract Tax:</span>
            <span className="text-[var(--yellow)]">{formatUsd(fees.tokenTaxUsd)}</span>
          </div>
        )}

        <div className="flex justify-between pt-1 border-t border-[var(--border)] col-span-2">
          <span className="font-bold text-[var(--yellow)]">Total Fees Breakdown:</span>
          <span className="font-bold text-[var(--yellow)] font-mono">{formatUsd(fees.totalFeesUsd)}</span>
        </div>

        <div className="flex justify-between pt-1 border-t border-[var(--border)] col-span-2 text-xs">
          <span className="font-bold text-[var(--teal)]">TOTAL ESTIMATED OUTLAY:</span>
          <span className="font-bold text-[var(--teal)] font-mono text-sm">{formatUsd(fees.totalCostUsd)}</span>
        </div>
      </div>

      {showAffordabilityNotice && (
        <div className="pt-1.5 border-t border-[var(--border)] text-[10px]">
          {fees.isAffordable ? (
            <div className="text-[var(--green)] flex items-center gap-1 font-semibold">
              <ShieldCheck size={12} />
              <span>Wallet balance verified. Required fees and safety gas reserves are covered.</span>
            </div>
          ) : (
            <div className="text-[var(--red)] flex items-center gap-1 font-semibold">
              <AlertCircle size={12} />
              <span>{fees.rejectionReason || 'Insufficient funds to cover trade and fees safely.'}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
