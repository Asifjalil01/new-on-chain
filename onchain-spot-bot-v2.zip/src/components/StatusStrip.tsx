import React from 'react';
import { useBot } from '../context/BotContext';
import { formatUsd } from '../utils/formatters';
import { AlertCircle, ShieldAlert, Lock, PauseCircle, PlayCircle } from 'lucide-react';

export const StatusStrip: React.FC = () => {
  const {
    config,
    botStatus,
    portfolio,
    positions,
    isBotStopped,
    handleSaveConfig,
  } = useBot();

  const mode = config.EXECUTION_MODE || 'paper';
  const chain = config.DEFAULT_CHAIN || 'solana';
  const totalBalance = portfolio.total_balance || 1600.0;
  const unrealizedPnl = portfolio.unrealized_pnl || 0.0;
  const unrealizedPnlPct = portfolio.unrealized_pnl_pct || 0.0;
  const realizedPnl = portfolio.realized_pnl || 0.0;
  const totalPnl = realizedPnl + unrealizedPnl;
  const maxPositions = config.MAX_POSITIONS || 5;
  const isScannerActive = botStatus.is_scanner_active;
  const nextScanSeconds = isBotStopped ? 0 : (botStatus.next_scan_seconds || 30);
  const allocationAmount = config.TRADE_ALLOCATION_AMOUNT || 0.005;
  const allocationCurrency = config.TRADE_ALLOCATION_CURRENCY || 'SOL';

  const chains = ['solana', 'ethereum', 'bsc', 'base', 'arbitrum', 'polygon', 'avalanche', 'optimism'];

  return (
    <div className={`h-[36px] border-b border-[var(--border)] px-3 flex items-center justify-between text-xs select-none font-mono shrink-0 transition-colors ${
      isBotStopped
        ? 'bg-[var(--yellow)]/10 border-[var(--yellow)]/40 text-[var(--yellow)]'
        : (mode === 'live' ? 'bg-[var(--red)]/10 border-[var(--red)]/30' : 'bg-[var(--card)]')
    }`}>
      {/* Left items */}
      <div className="flex items-center gap-4 overflow-x-auto">
        {/* Stopped Banner / Mode status */}
        {isBotStopped ? (
          <div className="flex items-center gap-1.5 font-bold text-[var(--yellow)] shrink-0">
            <PauseCircle size={14} className="animate-pulse" />
            <span>BOT STOPPED — ENGINE, BUYING & AUTO-REFRESH FROZEN</span>
            <span className="text-[10px] text-[var(--dim)] hidden md:inline">
              (Stop-loss protection active | 0 new orders allowed)
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 shrink-0">
            <PlayCircle size={14} className="text-[var(--teal)]" />
            <span className="text-[var(--dim)] uppercase font-semibold">ENGINE:</span>
            <span className="text-[var(--teal)] font-bold">RUNNING</span>
          </div>
        )}

        {/* Quick Chain Switch */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[var(--dim)] uppercase font-semibold">CHAIN:</span>
          <select
            value={chain.toLowerCase()}
            onChange={(e) => handleSaveConfig({ ...config, DEFAULT_CHAIN: e.target.value })}
            className="bg-[var(--panel)] border border-[var(--border-bright)] text-[var(--text)] px-1.5 py-0.2 rounded text-[11px] focus:outline-none focus:border-[var(--teal)] cursor-pointer"
          >
            {chains.map((c) => (
              <option key={c} value={c}>
                {c.toUpperCase()}
              </option>
            ))}
          </select>
        </div>

        {/* Allocation */}
        <div className="flex items-center gap-1.5 shrink-0 bg-[var(--panel)]/70 px-2 py-0.5 rounded border border-[var(--border)]">
          <span className="text-[var(--dim)] uppercase font-semibold">ORDER SIZE:</span>
          <span className="text-[var(--teal)] font-bold">
            {allocationAmount} {allocationCurrency}
          </span>
        </div>

        {/* Positions Count */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[var(--dim)] uppercase font-semibold">POSITIONS:</span>
          <span className="text-[var(--text)] font-bold">{positions.length} / {maxPositions}</span>
        </div>

        {/* Capital */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[var(--dim)] uppercase font-semibold">CAPITAL:</span>
          <span className="text-[var(--text)] font-bold">{formatUsd(totalBalance)}</span>
        </div>

        {/* P&L */}
        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[var(--dim)] uppercase font-semibold">P&L:</span>
          <span className={`font-bold ${totalPnl >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {totalPnl >= 0 ? '+' : ''}{formatUsd(totalPnl)} ({unrealizedPnlPct >= 0 ? '+' : ''}{unrealizedPnlPct.toFixed(2)}%)
          </span>
        </div>
      </div>

      {/* Right items: Scan Status / Countdown */}
      <div className="flex items-center gap-3 shrink-0 text-[11px]">
        {/* Next Scan countdown (Frozen when stopped) */}
        <div className="flex items-center gap-1.5">
          <span className="text-[var(--dim)] uppercase">NEXT SCAN:</span>
          <span className={`font-bold ${isBotStopped ? 'text-[var(--dim)] line-through' : 'text-[var(--text)]'}`}>
            {isBotStopped ? 'FROZEN' : `${nextScanSeconds}s`}
          </span>
        </div>

        {/* On Stop Policy Badge */}
        <span className="hidden lg:inline text-[10px] text-[var(--dim)] border-l border-[var(--border)] pl-2">
          POLICY: {config.ON_STOP_POSITIONS_POLICY || 'keep_with_protection'}
        </span>
      </div>
    </div>
  );
};
