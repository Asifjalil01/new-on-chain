import React from 'react';
import {
  Sun,
  Moon,
  Wallet,
  Download,
  AlertTriangle,
  Lock,
  Radio,
  Layers,
  ChevronDown,
  PanelLeft,
} from 'lucide-react';
import { useBot } from '../context/BotContext';
import { formatUsd } from '../utils/formatters';

export const HeaderBar: React.FC = () => {
  const {
    config,
    botStatus,
    portfolio,
    positions,
    activeWallet,
    setIsWalletModalOpen,
    requestModeChange,
    theme,
    toggleTheme,
    handleSaveConfig,
    isBotStopped,
    toggleSidebar,
    sidebarState,
  } = useBot();

  const mode = config.EXECUTION_MODE || 'paper';
  const isLive = mode === 'live';
  const isTestnet = mode === 'testnet';
  const isPaper = mode === 'paper';
  const totalPnl = (portfolio.realized_pnl || 0) + (portfolio.unrealized_pnl || 0);

  const chains = ['solana', 'ethereum', 'bsc', 'base', 'arbitrum', 'polygon', 'avalanche', 'optimism'];

  return (
    <header className="h-[52px] bg-[var(--panel)] border-b border-[var(--border)] px-3 flex items-center justify-between select-none shrink-0 z-20">
      {/* Left: Brand & Interactive Mode Switcher */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={toggleSidebar}
          title={`Toggle Navigation Sidebar (Ctrl+B) [Current: ${sidebarState}]`}
          className="p-1.5 rounded border border-[var(--border)] text-[var(--muted)] hover:text-[var(--teal)] hover:border-[var(--teal)]/50 bg-[var(--card)] cursor-pointer transition-colors"
        >
          <PanelLeft size={15} />
        </button>

        <div className="flex items-center gap-1.5">
          <span className="text-[var(--teal)] font-bold text-base tracking-wider">◈ ON-CHAIN SPOT BOT</span>
          <span className="text-[10px] text-[var(--teal)] font-bold px-1.5 py-0.2 rounded border border-[var(--teal)]/40 bg-[var(--card)]">
            v2.3.1
          </span>
        </div>

        {/* Interactive Mode Switcher */}
        <div className="flex items-center text-xs font-bold border border-[var(--border)] rounded overflow-hidden p-0.5 bg-[var(--bg)]">
          <button
            onClick={() => requestModeChange('paper')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
              isPaper
                ? 'bg-[var(--teal)] text-[var(--bg)] font-bold shadow-xs'
                : 'text-[var(--muted)] hover:text-[var(--text)]'
            }`}
            title="Switch to Dry Run / Paper trading simulation"
          >
            DRY RUN / PAPER
          </button>
          <button
            onClick={() => requestModeChange('testnet')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
              isTestnet
                ? 'bg-[var(--blue)] text-[var(--bg)] font-bold shadow-xs'
                : 'text-[var(--muted)] hover:text-[var(--text)]'
            }`}
            title="Switch to Testnet / Devnet RPCs"
          >
            TESTNET
          </button>
          <button
            onClick={() => requestModeChange('live')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-all flex items-center gap-1 ${
              isLive
                ? 'bg-[var(--red)] text-white font-bold shadow-xs animate-pulse'
                : 'text-[var(--muted)] hover:text-[var(--red)]'
            }`}
            title="Switch to Live On-Chain Trading (Requires typed confirmation)"
          >
            {isLive && <Lock size={10} />}
            <span>LIVE</span>
          </button>
        </div>

        {/* Persistent Red Live Badge */}
        {isLive && (
          <span className="bg-[var(--red)] text-white px-2 py-0.5 rounded text-[10px] font-bold tracking-wider animate-pulse flex items-center gap-1">
            <Lock size={10} />
            <span>REAL ASSETS</span>
          </span>
        )}

        {/* Emergency Pause Warning */}
        {botStatus.is_emergency_paused && (
          <span className="bg-[var(--red)]/20 text-[var(--red)] border border-[var(--red)] px-2 py-0.5 text-[10px] font-bold animate-pulse">
            EMERGENCY PAUSE ENGAGED
          </span>
        )}

        {/* Stopped Indicator */}
        {isBotStopped && !botStatus.is_emergency_paused && (
          <span className="bg-[var(--yellow)]/20 text-[var(--yellow)] border border-[var(--yellow)] px-2 py-0.5 text-[10px] font-bold">
            ENGINE STOPPED
          </span>
        )}
      </div>

      {/* Middle: Chain Selector & Status Chips */}
      <div className="hidden xl:flex items-center gap-4 text-xs font-mono">
        {/* Chain Selector */}
        <div className="flex items-center gap-1.5 bg-[var(--card)] px-2 py-1 rounded border border-[var(--border)]">
          <span className="text-[10px] text-[var(--dim)] uppercase font-semibold">CHAIN:</span>
          <select
            value={(config.DEFAULT_CHAIN || 'solana').toLowerCase()}
            onChange={(e) => handleSaveConfig({ ...config, DEFAULT_CHAIN: e.target.value })}
            className="bg-transparent text-[var(--text)] text-xs font-bold uppercase focus:outline-none cursor-pointer"
          >
            {chains.map((ch) => (
              <option key={ch} value={ch} className="bg-[var(--card)] text-[var(--text)]">
                {ch.toUpperCase()}
              </option>
            ))}
          </select>
        </div>

        {/* Capital */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[var(--dim)] uppercase font-semibold">CAPITAL:</span>
          <span className="font-bold text-[var(--text)]">{formatUsd(portfolio.total_balance || 1600)}</span>
        </div>

        {/* P&L */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[var(--dim)] uppercase font-semibold">P&L:</span>
          <span className={`font-bold ${totalPnl >= 0 ? 'text-[var(--green)]' : 'text-[var(--red)]'}`}>
            {totalPnl >= 0 ? '+' : ''}{formatUsd(totalPnl)}
          </span>
        </div>

        {/* Positions */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[var(--dim)] uppercase font-semibold">POSITIONS:</span>
          <span className="font-bold text-[var(--text)]">{positions.length} / {config.MAX_POSITIONS || 5}</span>
        </div>

        {/* Scanner State */}
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-[var(--dim)] uppercase font-semibold">SCANNER:</span>
          <span className={`font-bold flex items-center gap-1 ${botStatus.is_scanner_active ? 'text-[var(--teal)]' : 'text-[var(--muted)]'}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${botStatus.is_scanner_active && !isBotStopped ? 'bg-[var(--teal)] animate-ping' : 'bg-[var(--dim)]'}`}></span>
            {isBotStopped ? 'HALTED' : (botStatus.is_scanner_active ? 'ACTIVE' : 'IDLE')}
          </span>
        </div>
      </div>

      {/* Right: Wallet Selector, Download & Theme */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Active Wallet Chip */}
        <button
          onClick={() => setIsWalletModalOpen(true)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border text-xs font-semibold transition-all cursor-pointer shadow-xs ${
            isLive && (!activeWallet.address || activeWallet.id === 'paper')
              ? 'border-[var(--red)] bg-[var(--red)]/15 text-[var(--red)] animate-pulse'
              : 'border-[var(--border-bright)] bg-[var(--card)] text-[var(--text)] hover:border-[var(--teal)] hover:text-[var(--teal)]'
          }`}
          title={activeWallet.address ? `Connected: ${activeWallet.address} (${activeWallet.nativeBalance.toFixed(5)} ${activeWallet.nativeSymbol})` : 'Connect / Switch Crypto Wallet'}
        >
          <Wallet size={13} className={isLive ? 'text-[var(--red)]' : 'text-[var(--teal)]'} />
          <span className="truncate max-w-[140px]">
            {activeWallet.address && activeWallet.id !== 'paper'
              ? `${activeWallet.name.split(' ')[0]} (${activeWallet.address.slice(0, 4)}...${activeWallet.address.slice(-4)})`
              : (isLive ? 'Connect Real Wallet' : activeWallet.name)}
          </span>
          {activeWallet.address && (
            <span className="text-[10px] text-[var(--muted)] border-l border-[var(--border)] pl-1.5 ml-0.5 font-mono">
              {activeWallet.nativeBalance > 0 ? `${activeWallet.nativeBalance.toFixed(5)} ${activeWallet.nativeSymbol}` : `0.00 ${activeWallet.nativeSymbol}`}
            </span>
          )}
        </button>

        {/* Download Zip Project */}
        <a
          href="/api/download-project"
          download="onchain-spot-bot-v2.zip"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded border border-[var(--teal)] bg-[var(--teal)]/15 text-[var(--teal)] hover:bg-[var(--teal)] hover:text-[var(--bg)] font-bold text-xs transition-all cursor-pointer shadow-sm"
          title="Download complete bot package with GUI (.zip)"
        >
          <Download size={13} />
          <span className="hidden sm:inline">DOWNLOAD (.ZIP)</span>
        </a>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          title="Toggle Light/Dark Theme"
          className="p-1.5 rounded border border-[var(--border)] text-[var(--muted)] hover:text-[var(--teal)] hover:border-[var(--border-bright)] cursor-pointer"
        >
          {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
        </button>
      </div>
    </header>
  );
};
