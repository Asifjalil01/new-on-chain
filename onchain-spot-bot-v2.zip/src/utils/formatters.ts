/**
 * Formats token price without scientific notation, handling tiny micro-cap prices cleanly.
 */
export function formatPrice(price: number | undefined | null): string {
  if (price === undefined || price === null || isNaN(price)) return 'DATA UNAVAILABLE';
  if (price === 0) return '$0.00';
  if (price >= 10) return `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  if (price >= 1) return `$${price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 4 })}`;

  // Tiny prices under $1.00
  const str = price.toFixed(12).replace(/0+$/, '');
  const parts = str.split('.');
  if (parts.length === 2) {
    const decimals = parts[1];
    const leadingZeros = decimals.length - decimals.replace(/^0+/, '').length;
    if (leadingZeros >= 4) {
      const sigFigs = decimals.slice(leadingZeros, leadingZeros + 4);
      return `$0.0{${leadingZeros}}${sigFigs}`;
    }
  }
  return `$${str}`;
}

/**
 * Formats financial values with full comma separators and exact decimal amounts.
 * NEVER abbreviates (no $1.6K or $2.4M). Displays exact numbers like $1,600.00 or $125.50.
 * Automatically handles sub-cent fees (e.g. $0.0012) accurately without rounding to 0.
 */
export function formatUsd(amount: number | undefined | null, forceDecimals?: number): string {
  if (amount === undefined || amount === null || isNaN(amount)) return '$0.00';
  
  const abs = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';

  if (forceDecimals !== undefined) {
    return `${sign}$${abs.toLocaleString('en-US', { minimumFractionDigits: forceDecimals, maximumFractionDigits: forceDecimals })}`;
  }

  // Handle micro-fees gracefully (e.g. $0.001 or $0.00005)
  if (abs > 0 && abs < 0.01) {
    return `${sign}$${abs.toLocaleString('en-US', { minimumFractionDigits: 3, maximumFractionDigits: 6 })}`;
  }

  return `${sign}$${abs.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * Formats native crypto token amounts (e.g., "0.0050 SOL" or "0.0210 ETH")
 */
export function formatCryptoAmount(amount: number | undefined | null, symbol: string = 'SOL', maxDecimals: number = 4): string {
  if (amount === undefined || amount === null || isNaN(amount)) return `0.0000 ${symbol}`;
  return `${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: maxDecimals })} ${symbol}`;
}

export function formatTimeAgo(timestampMs: number): string {
  const elapsed = Math.floor((Date.now() - timestampMs) / 1000);
  if (elapsed < 60) return `${elapsed}s`;
  if (elapsed < 3600) return `${Math.floor(elapsed / 60)}m ${elapsed % 60}s`;
  if (elapsed < 86400) return `${Math.floor(elapsed / 3600)}h ${Math.floor((elapsed % 3600) / 60)}m`;
  return `${Math.floor(elapsed / 86400)}d`;
}
