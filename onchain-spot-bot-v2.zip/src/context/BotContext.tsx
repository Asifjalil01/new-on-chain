import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { walletManager, WalletInfo, WalletId } from '../wallets/WalletManager';

export interface BotContextType {
  // Navigation & Route
  currentTab: string;
  navigateToTab: (tabId: string) => void;
  detailToken: any | null;
  setDetailToken: (token: any | null) => void;

  // Bot State & Telemetry
  status: any;
  botStatus: any;
  config: any;
  portfolio: any;
  discoveryStats: any;
  isBotStopped: boolean;
  lifecycleState: string;

  // Domain Collections
  positions: any[];
  trades: any[];
  logs: any[];
  coverage: any;
  defenseData: any;
  wallets: any[];
  universeTokens: any[];
  universeTotal: number;
  universeCounts: any;

  // Multi-Wallet
  activeWallet: WalletInfo;
  walletDiagnostics: any;
  isWalletModalOpen: boolean;
  setIsWalletModalOpen: (open: boolean) => void;
  connectWallet: (id: WalletId) => Promise<boolean>;
  connectWatchOnlyAddress: (id: WalletId, address: string, name?: string) => Promise<boolean>;
  selectActiveWallet: (id: WalletId) => void;
  disconnectWallet: (id: WalletId) => void;
  refreshWalletBalance: () => Promise<void>;

  // Mode Switch & Safety
  isLiveConfirmOpen: boolean;
  setIsLiveConfirmOpen: (open: boolean) => void;
  requestModeChange: (targetMode: 'paper' | 'testnet' | 'live') => void;
  confirmLiveMode: () => Promise<boolean>;

  // Scanner Filtering Preferences (Survives Navigation)
  scannerPage: number;
  setScannerPage: (p: number) => void;
  selectedCategory: string;
  setSelectedCategory: (c: string) => void;
  selectedChain: string;
  setSelectedChain: (ch: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  scannerSortBy: string;
  setScannerSortBy: (s: string) => void;

  // Theme & Layout
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  sidebarState: 'expanded' | 'collapsed' | 'hidden';
  setSidebarState: (state: 'expanded' | 'collapsed' | 'hidden') => void;
  toggleSidebar: () => void;

  // Actions
  handleControlAction: (action: string) => Promise<void>;
  handleSaveConfig: (newConfig: any) => Promise<boolean>;
  handleSellPosition: (positionId: string) => Promise<void>;
  handleSellAll: () => Promise<void>;
  handleInspectToken: (chain: string, address: string) => void;
  refreshTelemetry: () => Promise<void>;
  refreshUniverse: () => Promise<void>;
}

const BotContext = createContext<BotContextType | null>(null);

// Scanner prefs storage key
const SCANNER_PREFS_KEY = 'onchain_spot_scanner_prefs_v2';
const SAVED_TAB_KEY = 'onchain_spot_active_tab_v2';

export const BotProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // ---------------- ROUTING & TAB NAVIGATION ----------------
  const getInitialTab = (): string => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.replace(/^#\/?/, '').split('/')[0];
      if (hash && ['dashboard', 'scanner', 'token_detail', 'coverage', 'rug_defense', 'wallets', 'history', 'settings', 'docs'].includes(hash)) {
        return hash;
      }
      const saved = localStorage.getItem(SAVED_TAB_KEY);
      if (saved) return saved;
    }
    return 'dashboard';
  };

  const [currentTab, setCurrentTabState] = useState<string>(getInitialTab);
  const [detailToken, setDetailToken] = useState<any | null>(null);

  const navigateToTab = useCallback((tabId: string) => {
    setCurrentTabState(tabId);
    if (typeof window !== 'undefined') {
      localStorage.setItem(SAVED_TAB_KEY, tabId);
      window.location.hash = `#/${tabId}`;
    }
  }, []);

  // Listen to browser hash popstate
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace(/^#\/?/, '').split('/')[0];
      if (hash && hash !== currentTab && ['dashboard', 'scanner', 'token_detail', 'coverage', 'rug_defense', 'wallets', 'history', 'settings', 'docs'].includes(hash)) {
        setCurrentTabState(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, [currentTab]);

  // ---------------- SCANNER PREFERENCES (PERSISTENT) ----------------
  const loadSavedScannerPrefs = () => {
    try {
      const raw = localStorage.getItem(SCANNER_PREFS_KEY);
      if (raw) return JSON.parse(raw);
    } catch {}
    return null;
  };

  const savedPrefs = loadSavedScannerPrefs();
  const [scannerPage, setScannerPageRaw] = useState<number>(savedPrefs?.page || 1);
  const [selectedCategory, setSelectedCategoryRaw] = useState<string>(savedPrefs?.category || 'ALL');
  const [selectedChain, setSelectedChainRaw] = useState<string>(savedPrefs?.chain || 'all');
  const [searchQuery, setSearchQueryRaw] = useState<string>(savedPrefs?.search || '');
  const [scannerSortBy, setScannerSortByRaw] = useState<string>(savedPrefs?.sortBy || 'score');

  const saveScannerPrefs = (updates: any) => {
    try {
      const current = loadSavedScannerPrefs() || {};
      const merged = {
        page: scannerPage,
        category: selectedCategory,
        chain: selectedChain,
        search: searchQuery,
        sortBy: scannerSortBy,
        ...updates,
      };
      localStorage.setItem(SCANNER_PREFS_KEY, JSON.stringify(merged));
    } catch {}
  };

  const setScannerPage = (p: number) => {
    setScannerPageRaw(p);
    saveScannerPrefs({ page: p });
  };
  const setSelectedCategory = (c: string) => {
    setSelectedCategoryRaw(c);
    setScannerPageRaw(1);
    saveScannerPrefs({ category: c, page: 1 });
  };
  const setSelectedChain = (ch: string) => {
    setSelectedChainRaw(ch);
    setScannerPageRaw(1);
    saveScannerPrefs({ chain: ch, page: 1 });
  };
  const setSearchQuery = (q: string) => {
    setSearchQueryRaw(q);
    setScannerPageRaw(1);
    saveScannerPrefs({ search: q, page: 1 });
  };
  const setScannerSortBy = (s: string) => {
    setScannerSortByRaw(s);
    setScannerPageRaw(1);
    saveScannerPrefs({ sortBy: s, page: 1 });
  };

  // ---------------- THEME & SIDEBAR ----------------
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('onchain_spot_theme') as 'dark' | 'light';
      return saved || 'dark';
    }
    return 'dark';
  });

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    setTheme(next);
    localStorage.setItem('onchain_spot_theme', next);
    document.documentElement.setAttribute('data-theme', next);
  };

  const [sidebarState, setSidebarStateRaw] = useState<'expanded' | 'collapsed' | 'hidden'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('onchain_sidebar_state') as 'expanded' | 'collapsed' | 'hidden';
      if (saved && ['expanded', 'collapsed', 'hidden'].includes(saved)) return saved;
    }
    return 'expanded';
  });

  const setSidebarState = (next: 'expanded' | 'collapsed' | 'hidden') => {
    setSidebarStateRaw(next);
    if (typeof window !== 'undefined') {
      localStorage.setItem('onchain_sidebar_state', next);
    }
  };

  const toggleSidebar = () => {
    setSidebarStateRaw((prev) => {
      const next = prev === 'expanded' ? 'collapsed' : 'expanded';
      if (typeof window !== 'undefined') {
        localStorage.setItem('onchain_sidebar_state', next);
      }
      return next;
    });
  };

  // ---------------- CORE API STATE ----------------
  const [status, setStatus] = useState<any>(null);
  const [positions, setPositions] = useState<any[]>([]);
  const [trades, setTrades] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [coverage, setCoverage] = useState<any>(null);
  const [defenseData, setDefenseData] = useState<any>(null);
  const [wallets, setWallets] = useState<any[]>([]);

  // Universe
  const [universeTokens, setUniverseTokens] = useState<any[]>([]);
  const [universeTotal, setUniverseTotal] = useState<number>(0);
  const [universeCounts, setUniverseCounts] = useState<any>({
    ALL: 0, BUY: 0, WATCH: 0, WAIT: 0, REJECT: 0, 'RUG RISK': 0, HONEYPOT: 0, POSITION: 0, COOLDOWN: 0,
  });

  // Derived state with stable references to prevent unnecessary dashboard rerenders
  const config = useMemo(() => status?.config || {
    EXECUTION_MODE: 'paper',
    DEFAULT_CHAIN: 'solana',
    TOTAL_CAPITAL_USD: 1600.0,
    MAX_POSITIONS: 5,
  }, [status?.config]);

  const botState = useMemo(() => status?.status || {
    is_running: true,
    is_scanner_active: true,
    is_buying_paused: false,
    is_emergency_paused: false,
    lifecycle_state: 'RUNNING',
  }, [status?.status]);

  const portfolio = useMemo(() => status?.portfolio || {
    total_balance: 1600.0,
    cash_balance: 1600.0,
    invested_capital: 0,
    unrealized_pnl: 0,
    unrealized_pnl_pct: 0,
    realized_pnl: 0,
    open_positions_count: 0,
  }, [status?.portfolio]);

  const discoveryStats = status?.discovery_stats || null;

  const lifecycleState = botState.lifecycle_state || (botState.is_running ? 'RUNNING' : 'STOPPED');
  const isBotStopped = lifecycleState === 'STOPPED' || (!botState.is_running && !botState.is_emergency_paused);

  // ---------------- WALLETS ----------------
  const [isWalletModalOpen, setIsWalletModalOpen] = useState<boolean>(false);
  const [activeWallet, setActiveWallet] = useState<WalletInfo>(() => walletManager.getActiveWallet());
  const [walletDiagnostics, setWalletDiagnostics] = useState<any>(() =>
    walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana')
  );

  useEffect(() => {
    walletManager.setMode(config.EXECUTION_MODE || 'paper');
    walletManager.setChain(config.DEFAULT_CHAIN || 'solana');
    return walletManager.subscribe(() => {
      const active = walletManager.getActiveWallet();
      setActiveWallet(active);
      setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
    });
  }, [config.EXECUTION_MODE, config.DEFAULT_CHAIN]);

  // Periodic on-chain wallet balance refresh
  useEffect(() => {
    const refreshActiveOnChain = async () => {
      const active = walletManager.getActiveWallet();
      if (active.address && active.id !== 'paper') {
        await walletManager.refreshOnChainBalance(active.id);
        await walletManager.syncToBackend(active.id);
        setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
      }
    };

    refreshActiveOnChain();
    const interval = setInterval(refreshActiveOnChain, 15000);
    return () => clearInterval(interval);
  }, [config.DEFAULT_CHAIN, config.EXECUTION_MODE]);

  const refreshWalletBalance = useCallback(async () => {
    const active = walletManager.getActiveWallet();
    if (active.address && active.id !== 'paper') {
      await walletManager.refreshOnChainBalance(active.id);
      await walletManager.syncToBackend(active.id);
      setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
      refreshWallets();
      refreshTelemetry();
    }
  }, [config.DEFAULT_CHAIN]);

  const connectWallet = async (id: WalletId): Promise<boolean> => {
    const success = await walletManager.connectWallet(id);
    if (success) {
      const active = walletManager.getActiveWallet();
      setActiveWallet(active);
      setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
      await refreshWallets();
      await refreshTelemetry();
    }
    return success;
  };

  const connectWatchOnlyAddress = async (id: WalletId, address: string, name?: string): Promise<boolean> => {
    const success = await walletManager.connectWatchOnlyAddress(id, address, name);
    if (success) {
      const active = walletManager.getActiveWallet();
      setActiveWallet(active);
      setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
      await refreshWallets();
      await refreshTelemetry();
    }
    return success;
  };

  const selectActiveWallet = (id: WalletId) => {
    walletManager.setActiveWallet(id);
    setActiveWallet(walletManager.getActiveWallet());
    setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
  };

  const disconnectWallet = (id: WalletId) => {
    walletManager.disconnectWallet(id);
    setActiveWallet(walletManager.getActiveWallet());
    setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
    try {
      fetch('/api/wallets/disconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chain: config.DEFAULT_CHAIN || 'solana' }),
      });
    } catch {}
  };

  // ---------------- LIVE CONFIRMATION MODAL ----------------
  const [isLiveConfirmOpen, setIsLiveConfirmOpen] = useState<boolean>(false);

  const requestModeChange = async (targetMode: 'paper' | 'testnet' | 'live') => {
    if (targetMode === 'live') {
      setIsLiveConfirmOpen(true);
      return;
    }
    // Direct switch for paper or testnet
    await handleSaveConfig({ ...config, EXECUTION_MODE: targetMode });
    walletManager.setMode(targetMode);
    refreshTelemetry();
  };

  const confirmLiveMode = async (): Promise<boolean> => {
    // Switching to Live: Stop bot first per safety spec
    await handleControlAction('stop_bot');
    const ok = await handleSaveConfig({ ...config, EXECUTION_MODE: 'live' });
    if (ok) {
      walletManager.setMode('live');
      setIsLiveConfirmOpen(false);
      refreshTelemetry();
      refreshWallets();
      return true;
    }
    return false;
  };

  // ---------------- DATA FETCHING ----------------
  const refreshTelemetry = useCallback(async (includeLogs = false) => {
    try {
      const fetches: Promise<Response>[] = [
        fetch('/api/status'),
        fetch('/api/positions'),
      ];
      if (includeLogs) {
        fetches.push(fetch('/api/logs'));
      }

      const results = await Promise.all(fetches);
      const [statusRes, posRes] = results;

      if (statusRes && statusRes.ok) {
        const sData = await statusRes.json();
        setStatus(sData);
      }
      if (posRes && posRes.ok) {
        const pData = await posRes.json();
        setPositions(pData);
      }
      if (includeLogs && results[2] && results[2].ok) {
        setLogs(await results[2].json());
      }
    } catch {}
  }, []);

  const refreshUniverse = useCallback(async () => {
    try {
      const params = new URLSearchParams({
        page: scannerPage.toString(),
        limit: '40',
        chain: selectedChain,
        state: selectedCategory === 'ALL' ? 'all' : selectedCategory,
        search: searchQuery,
        sort_by: scannerSortBy,
      });

      const res = await fetch(`/api/universe?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setUniverseTokens(data.tokens || []);
        setUniverseTotal(data.total || 0);
        if (data.counts) setUniverseCounts(data.counts);
      }
    } catch {}
  }, [scannerPage, selectedChain, selectedCategory, searchQuery, scannerSortBy]);

  const refreshWallets = useCallback(async () => {
    try {
      const res = await fetch(`/api/wallets?mode=${config.EXECUTION_MODE || 'paper'}`);
      if (res.ok) setWallets(await res.json());
    } catch {}
  }, [config.EXECUTION_MODE]);

  // Tab-specific fetch
  const fetchTabData = useCallback(async (tab: string) => {
    try {
      if (tab === 'history') {
        const res = await fetch('/api/trades');
        if (res.ok) setTrades(await res.json());
      } else if (tab === 'coverage') {
        const res = await fetch('/api/coverage');
        if (res.ok) setCoverage(await res.json());
      } else if (tab === 'rug_defense') {
        const res = await fetch('/api/rug-defense');
        if (res.ok) setDefenseData(await res.json());
      } else if (tab === 'wallets') {
        refreshWallets();
      }
    } catch {}
  }, [refreshWallets]);

  // ---------------- SSE EVENT STREAM & FREEZE LOGIC ----------------
  // When STOPPED, auto-polling stops and UI freezes!
  useEffect(() => {
    refreshTelemetry(true);
    refreshUniverse();
  }, []);

  useEffect(() => {
    fetchTabData(currentTab);
  }, [currentTab, fetchTabData]);

  // Polling loop with STOPPED FREEZE check (heartbeat backup every 8s)
  useEffect(() => {
    if (isBotStopped) {
      // STOPPED: Polling is completely DISABLED. Board and tickers freeze.
      return;
    }

    const interval = setInterval(() => {
      refreshTelemetry(false);
    }, 8000);

    return () => clearInterval(interval);
  }, [isBotStopped, refreshTelemetry]);

  // SSE subscription for zero-polling background updates
  useEffect(() => {
    let evtSource: EventSource | null = null;
    try {
      evtSource = new EventSource('/api/events');
      evtSource.addEventListener('status', (e) => {
        try {
          const updated = JSON.parse(e.data);
          setStatus((prev: any) => prev ? { ...prev, status: updated } : prev);
        } catch {}
      });
      evtSource.addEventListener('log', (e) => {
        try {
          const newLog = JSON.parse(e.data);
          setLogs((prev) => [newLog, ...prev.slice(0, 199)]);
        } catch {}
      });
      // Real-time sub-second price stream: updates current prices without refreshing full dashboard
      evtSource.addEventListener('positions_batch_update', (e) => {
        if (isBotStopped) return;
        try {
          const payload = JSON.parse(e.data);
          if (payload && Array.isArray(payload.positions)) {
            setPositions((prev) => {
              if (prev.length !== payload.positions.length) {
                return payload.positions;
              }
              let hasChanged = false;
              const next = prev.map((oldPos) => {
                const fresh = payload.positions.find((p: any) => p.position_id === oldPos.position_id);
                if (!fresh) {
                  hasChanged = true;
                  return oldPos;
                }
                if (
                  oldPos.current_price_usd !== fresh.current_price_usd ||
                  oldPos.current_profit_percent !== fresh.current_profit_percent ||
                  oldPos.net_profit_percent !== fresh.net_profit_percent ||
                  oldPos.peak_price_usd !== fresh.peak_price_usd ||
                  oldPos.peak_profit_percent !== fresh.peak_profit_percent ||
                  oldPos.trailing_floor_price_usd !== fresh.trailing_floor_price_usd ||
                  oldPos.state !== fresh.state ||
                  oldPos.data_age_seconds !== fresh.data_age_seconds ||
                  oldPos.is_price_stale !== fresh.is_price_stale
                ) {
                  hasChanged = true;
                  return fresh;
                }
                return oldPos;
              });
              return hasChanged ? next : prev;
            });
          }
        } catch {}
      });
      evtSource.addEventListener('position_update', (e) => {
        if (!isBotStopped) {
          try {
            const payload = JSON.parse(e.data);
            if (payload && payload.position) {
              setPositions((prev) => {
                const idx = prev.findIndex(p => p.position_id === payload.position.position_id);
                if (idx >= 0) {
                  const copy = [...prev];
                  copy[idx] = payload.position;
                  return copy;
                }
                return [payload.position, ...prev];
              });
              return;
            }
          } catch {}
          fetch('/api/positions').then((r) => {
            if (r.ok) r.json().then(setPositions);
          });
        }
      });
      evtSource.addEventListener('trade_closed', () => {
        if (!isBotStopped) {
          fetch('/api/positions').then((r) => {
            if (r.ok) r.json().then(setPositions);
          });
          fetch('/api/trades').then((r) => {
            if (r.ok) r.json().then(setTrades);
          });
        }
      });
      evtSource.addEventListener('universe_cleared', () => {
        setUniverseTokens([]);
        setUniverseTotal(0);
      });
    } catch {}

    return () => {
      if (evtSource) evtSource.close();
    };
  }, [isBotStopped]);

  // When filters change, update universe
  useEffect(() => {
    refreshUniverse();
  }, [refreshUniverse]);

  // ---------------- USER ACTIONS ----------------
  const handleControlAction = async (action: string) => {
    try {
      if (action === 'start_bot' && config.EXECUTION_MODE === 'live') {
        const active = walletManager.getActiveWallet();
        if (active.id !== 'paper' && active.address) {
          await walletManager.refreshOnChainBalance(active.id);
          await walletManager.syncToBackend(active.id);
          setWalletDiagnostics(walletManager.getWalletDiagnostics(config.DEFAULT_CHAIN || 'solana'));
        }
      }

      const res = await fetch('/api/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Action failed');
      }
      await refreshTelemetry();
      if (action !== 'stop_bot') {
        refreshUniverse();
      }
    } catch (err: any) {
      console.error('Control action error:', err);
    }
  };

  const handleSellPosition = async (positionId: string) => {
    try {
      await fetch(`/api/positions/${positionId}/sell`, { method: 'POST' });
      refreshTelemetry();
    } catch {}
  };

  const handleSellAll = async () => {
    try {
      await fetch('/api/positions/sell-all', { method: 'POST' });
      refreshTelemetry();
    } catch {}
  };

  const handleInspectToken = (chain: string, address: string) => {
    const found = universeTokens.find(
      t => t.chain.toLowerCase() === chain.toLowerCase() &&
           t.token_address.toLowerCase() === address.toLowerCase()
    );
    if (found) {
      setDetailToken(found);
      navigateToTab('token_detail');
    } else {
      fetch(`/api/token/${chain}/${address}`)
        .then(r => r.ok ? r.json() : null)
        .then(t => {
          if (t) {
            setDetailToken(t);
            navigateToTab('token_detail');
          }
        });
    }
  };

  const handleSaveConfig = async (newConfig: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig),
      });
      if (res.ok) {
        await refreshTelemetry();
        return true;
      }
      const data = await res.json();
      alert(data.error || 'Failed to save configuration');
      return false;
    } catch {
      return false;
    }
  };

  return (
    <BotContext.Provider
      value={{
        currentTab,
        navigateToTab,
        detailToken,
        setDetailToken,
        status,
        botStatus: botState,
        config,
        portfolio,
        discoveryStats,
        isBotStopped,
        lifecycleState,
        positions,
        trades,
        logs,
        coverage,
        defenseData,
        wallets,
        universeTokens,
        universeTotal,
        universeCounts,
        activeWallet,
        walletDiagnostics,
        isWalletModalOpen,
        setIsWalletModalOpen,
        connectWallet,
        connectWatchOnlyAddress,
        selectActiveWallet,
        disconnectWallet,
        refreshWalletBalance,
        isLiveConfirmOpen,
        setIsLiveConfirmOpen,
        requestModeChange,
        confirmLiveMode,
        scannerPage,
        setScannerPage,
        selectedCategory,
        setSelectedCategory,
        selectedChain,
        setSelectedChain,
        searchQuery,
        setSearchQuery,
        scannerSortBy,
        setScannerSortBy,
        theme,
        toggleTheme,
        sidebarState,
        setSidebarState,
        toggleSidebar,
        handleControlAction,
        handleSaveConfig,
        handleSellPosition,
        handleSellAll,
        handleInspectToken,
        refreshTelemetry,
        refreshUniverse,
      }}
    >
      {children}
    </BotContext.Provider>
  );
};

export const useBot = () => {
  const ctx = useContext(BotContext);
  if (!ctx) throw new Error('useBot must be used within BotProvider');
  return ctx;
};
