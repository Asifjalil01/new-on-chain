import React from 'react';
import { BotProvider, useBot } from './context/BotContext';
import { HeaderBar } from './components/HeaderBar';
import { StatusStrip } from './components/StatusStrip';
import { Sidebar } from './components/Sidebar';
import { BottomControlBar } from './components/BottomControlBar';
import { DashboardView } from './components/DashboardView';
import { ScannerView } from './components/ScannerView';
import { TokenDetailView } from './components/TokenDetailView';
import { CoverageView } from './components/CoverageView';
import { RugDefenseView } from './components/RugDefenseView';
import { WalletsView } from './components/WalletsView';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';
import { DocsView } from './components/DocsView';
import { WalletConnectModal } from './components/WalletConnectModal';
import { LiveConfirmModal } from './components/LiveConfirmModal';

function BotAppContent() {
  const {
    currentTab,
    navigateToTab,
    positions,
    portfolio,
    logs,
    universeTokens,
    universeTotal,
    universeCounts,
    discoveryStats,
    scannerPage,
    setScannerPage,
    selectedCategory,
    setSelectedCategory,
    selectedChain,
    setSelectedChain,
    searchQuery,
    setSearchQuery,
    scannerSortBy,
    setScannerSortBy,
    detailToken,
    coverage,
    defenseData,
    trades,
    config,
    handleSellPosition,
    handleSellAll,
    handleInspectToken,
    handleControlAction,
    handleSaveConfig,
    isWalletModalOpen,
    setIsWalletModalOpen,
    selectActiveWallet,
  } = useBot();

  return (
    <div className="w-screen h-screen flex flex-col bg-[var(--bg)] text-[var(--text)] select-none overflow-hidden">
      {/* Top HeaderBar */}
      <HeaderBar />

      {/* Quick Status Strip with Freeze & Stopped Banner */}
      <StatusStrip />

      {/* Middle Layout: Persistent Left Sidebar + Main Content View */}
      <div className="flex-1 flex overflow-hidden relative">
        <Sidebar />

        <main className="flex-1 flex flex-col overflow-hidden relative">
          {currentTab === 'dashboard' && (
            <DashboardView
              positions={positions}
              stats={portfolio}
              logs={logs}
              onSellPosition={handleSellPosition}
              onSellAll={handleSellAll}
              onInspectToken={handleInspectToken}
            />
          )}

          {currentTab === 'scanner' && (
            <ScannerView
              tokens={universeTokens}
              totalCount={universeTotal}
              currentPage={scannerPage}
              pageSize={40}
              counts={universeCounts}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              selectedChain={selectedChain}
              onSelectChain={setSelectedChain}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onPageChange={setScannerPage}
              onInspectToken={handleInspectToken}
              discoveryStats={discoveryStats}
              onResetSeenCache={() => handleControlAction('reset_seen_cache')}
              sortBy={scannerSortBy}
              onSortChange={setScannerSortBy}
            />
          )}

          {currentTab === 'token_detail' && (
            <TokenDetailView
              token={detailToken}
              onBack={() => navigateToTab('scanner')}
              onPaperBuy={async () => {
                await handleControlAction('paper_test_cycle');
                navigateToTab('dashboard');
              }}
            />
          )}

          {currentTab === 'coverage' && <CoverageView coverage={coverage} />}

          {currentTab === 'rug_defense' && <RugDefenseView defenseData={defenseData} />}

          {currentTab === 'wallets' && <WalletsView />}

          {currentTab === 'history' && <HistoryView trades={trades} />}

          {currentTab === 'settings' && (
            <SettingsView
              config={config}
              onSaveConfig={handleSaveConfig}
              onOpenWalletModal={() => setIsWalletModalOpen(true)}
            />
          )}

          {currentTab === 'docs' && <DocsView />}
        </main>
      </div>

      {/* Pinned Bottom Action Bar */}
      <BottomControlBar />

      {/* Multi-Wallet Modal */}
      <WalletConnectModal
        isOpen={isWalletModalOpen}
        onClose={() => setIsWalletModalOpen(false)}
        onWalletSelected={(w) => selectActiveWallet(w.id)}
      />

      {/* Live Mode Confirmation Modal */}
      <LiveConfirmModal />
    </div>
  );
}

export function App() {
  return (
    <BotProvider>
      <BotAppContent />
    </BotProvider>
  );
}

export default App;
